```tsx
import React from 'react';
import { MarketData } from '../../features/market/types';

interface MarketCardProps {
  market: MarketData;
}

export function MarketCard({ market }: MarketCardProps) {
  return (
    <div className="bg-dark-200 p-4 rounded-lg">
      <h2 className="text-white">{market.name}</h2>
      <p className="text-gray-400">${market.price.toLocaleString()}</p>
    </div>
  );
}
```