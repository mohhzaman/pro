import React from 'react';
import { useWallet } from '../../hooks/useWallet';
import { Bell, Wallet, Search } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { address, connect, disconnect } = useWallet();

  return (
    <nav className="bg-dark-200 border-b border-dark-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-1 flex items-center">
            <div className="flex-shrink-0">
              <div className="relative">
                <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search markets..."
                  className="w-64 bg-dark-100 text-white rounded-md pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="text-gray-300 hover:text-white relative">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-primary-500 rounded-full"></span>
            </button>
            
            {address ? (
              <button
                onClick={disconnect}
                className="flex items-center gap-2 px-4 py-2 rounded-md bg-dark-100 text-white hover:bg-dark-200"
              >
                <Wallet className="w-4 h-4" />
                {address.slice(0, 6)}...{address.slice(-4)}
              </button>
            ) : (
              <button
                onClick={connect}
                className="flex items-center gap-2 px-4 py-2 rounded-md bg-primary-600 text-white hover:bg-primary-500"
              >
                <Wallet className="w-4 h-4" />
                Connect Wallet
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};