```typescript
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Dashboard } from '../../pages/Dashboard';

export const Layout: React.FC = () => {
  return (
    <div className="min-h-screen bg-dark-300">
      <main className="flex-1 p-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
        </Routes>
      </main>
    </div>
  );
};
```