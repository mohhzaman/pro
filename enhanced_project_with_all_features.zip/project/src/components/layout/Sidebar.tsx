import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  LineChart, 
  Wallet,
  BarChart2,
  Newspaper, 
  Users, 
  Settings,
  Brain
} from 'lucide-react';

const navItems = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/trading', icon: LineChart, label: 'Trading' },
  { path: '/portfolio', icon: Wallet, label: 'Portfolio' },
  { path: '/markets', icon: BarChart2, label: 'Markets' },
  { path: '/news', icon: Newspaper, label: 'News' },
  { path: '/community', icon: Users, label: 'Community' },
  { path: '/settings', icon: Settings, label: 'Settings' }
];

export const Sidebar: React.FC = () => {
  const location = useLocation();

  return (
    <div className="w-64 bg-dark-200 h-screen flex-shrink-0">
      <div className="p-4">
        <div className="flex items-center gap-2 mb-8">
          <Brain className="w-8 h-8 text-primary-400" />
          <span className="text-xl font-bold text-white">NEUMORA</span>
        </div>
        <nav className="space-y-2">
          {navItems.map(({ path, icon: Icon, label }) => (
            <Link
              key={path}
              to={path}
              className={`flex items-center gap-3 px-4 py-2 rounded-md text-sm font-medium ${
                location.pathname === path
                  ? 'bg-primary-600/10 text-primary-400'
                  : 'text-gray-300 hover:bg-dark-100 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              {label}
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
};