import React from 'react';
import { ExternalLink, Clock } from 'lucide-react';
import { NewsArticle } from '../../../features/news/types';
import { formatDistanceToNow } from 'date-fns';

interface NewsGridProps {
  articles: NewsArticle[];
  isLoading: boolean;
  error: string | null;
}

export const NewsGrid: React.FC<NewsGridProps> = ({ articles, isLoading, error }) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-gray-800 rounded-lg h-96 animate-pulse" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-900/50 text-red-200 p-4 rounded-lg">
        {error}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {articles.map(article => (
        <article key={article.id} className="bg-gray-800 rounded-lg overflow-hidden">
          <img
            src={article.imageUrl}
            alt={article.title}
            className="w-full h-48 object-cover"
          />
          <div className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-blue-400">{article.source}</span>
              <span className="text-sm text-gray-400 flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {formatDistanceToNow(article.publishedAt, { addSuffix: true })}
              </span>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">
              {article.title}
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              {article.description}
            </p>
            <div className="flex items-center justify-between">
              <span className="px-2 py-1 bg-gray-700 text-sm text-white rounded">
                {article.category}
              </span>
              <a
                href={article.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-400 hover:text-blue-300 flex items-center gap-1"
              >
                Read more
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
};