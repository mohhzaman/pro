import React, { useState } from 'react';
import { NewsFilters } from './NewsFilters';
import { NewsGrid } from './NewsGrid';
import { TrendingNews } from './TrendingNews';
import { useNews } from '../../../features/news/hooks/useNews';

export const News: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const { articles, isLoading, error } = useNews();

  const filteredArticles = selectedCategory === 'All'
    ? articles
    : articles.filter(article => article.category === selectedCategory);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white mb-6">Crypto News</h1>
      
      <TrendingNews articles={articles.slice(0, 3)} />
      
      <NewsFilters 
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
      />
      
      <NewsGrid articles={filteredArticles} isLoading={isLoading} error={error} />
    </div>
  );
};