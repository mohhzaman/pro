import React from 'react';
import { Trending, ExternalLink } from 'lucide-react';
import { NewsArticle } from '../../../features/news/types';

interface TrendingNewsProps {
  articles: NewsArticle[];
}

export const TrendingNews: React.FC<TrendingNewsProps> = ({ articles }) => {
  return (
    <div className="bg-gray-800 rounded-lg p-6 mb-6">
      <div className="flex items-center gap-2 mb-4">
        <Trending className="w-5 h-5 text-blue-400" />
        <h2 className="text-xl font-bold text-white">Trending News</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {articles.map(article => (
          <a
            key={article.id}
            href={article.url}
            target="_blank"
            rel="noopener noreferrer"
            className="group"
          >
            <div className="relative h-48 mb-2 overflow-hidden rounded-lg">
              <img
                src={article.imageUrl}
                alt={article.title}
                className="w-full h-full object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="text-white font-semibold line-clamp-2 group-hover:text-blue-400">
                  {article.title}
                </h3>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">{article.source}</span>
              <span className="text-blue-400 flex items-center gap-1">
                Read more
                <ExternalLink className="w-4 h-4" />
              </span>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};