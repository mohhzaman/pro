import React from 'react';
import { useWallet } from '../../../hooks/useWallet';
import { Wallet, TrendingUp, TrendingDown, PieChart } from 'lucide-react';
import { formatCurrency } from '../../../utils/formatters';
import { usePortfolio } from '../../../hooks/usePortfolio';

export const PortfolioSummary: React.FC = () => {
  const { balance, address } = useWallet();
  const { holdings, totalValue, performance } = usePortfolio();

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold text-white">Portfolio Summary</h2>
        <div className="flex items-center gap-2">
          <Wallet className="w-5 h-5 text-blue-400" />
          {address ? (
            <span className="text-sm text-gray-400">
              {address.slice(0, 6)}...{address.slice(-4)}
            </span>
          ) : (
            <span className="text-sm text-gray-400">Not Connected</span>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div className="text-3xl font-bold text-white">
            {formatCurrency(totalValue)}
          </div>
          <div className="flex items-center gap-1 mt-1">
            {performance >= 0 ? (
              <>
                <TrendingUp className="w-4 h-4 text-green-400" />
                <span className="text-green-400">+{performance}%</span>
              </>
            ) : (
              <>
                <TrendingDown className="w-4 h-4 text-red-400" />
                <span className="text-red-400">{performance}%</span>
              </>
            )}
            <span className="text-gray-400 text-sm">24h</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <PieChart className="w-16 h-16 text-blue-400" />
          <div className="space-y-1">
            {holdings.slice(0, 3).map(holding => (
              <div key={holding.symbol} className="flex justify-between text-sm">
                <span className="text-gray-400">{holding.symbol}</span>
                <span className="text-white">{formatCurrency(holding.value)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};