import React from 'react';
import { MarketOverview } from './MarketOverview';
import { PortfolioSummary } from './PortfolioSummary';
import { TradingPositions } from './TradingPositions';
import { MarketSentiment } from './MarketSentiment';
import { NewsWidget } from './NewsWidget';
import { FavoritesList } from './FavoritesList';
import { AIInsights } from './AIInsights';

export const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white mb-6">Dashboard</h1>
      
      <MarketOverview />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <PortfolioSummary />
          <TradingPositions />
        </div>
        <div className="space-y-6">
          <MarketSentiment />
          <FavoritesList />
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <NewsWidget />
        <AIInsights />
      </div>
    </div>
  );
};