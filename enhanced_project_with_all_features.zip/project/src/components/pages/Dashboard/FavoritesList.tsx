import React from 'react';
import { Star, TrendingUp, TrendingDown } from 'lucide-react';
import { useMarketData } from '../../../features/market/hooks/useMarketData';
import { formatCurrency } from '../../../utils/formatters';
import { useFavorites } from '../../../hooks/useFavorites';

export const FavoritesList: React.FC = () => {
  const { favorites } = useFavorites();

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex items-center gap-2 mb-6">
        <Star className="w-5 h-5 text-yellow-400" />
        <h2 className="text-lg font-semibold text-white">Favorites</h2>
      </div>

      <div className="space-y-4">
        {favorites.map(symbol => (
          <FavoriteItem key={symbol} symbol={symbol} />
        ))}
      </div>
    </div>
  );
};

const FavoriteItem: React.FC<{ symbol: string }> = ({ symbol }) => {
  const { marketData } = useMarketData(`${symbol}/USD`);

  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="font-medium text-white">{symbol}</div>
        <div className="text-sm text-gray-400">
          {formatCurrency(marketData.price)}
        </div>
      </div>
      <div className="flex items-center gap-1">
        {marketData.change24h >= 0 ? (
          <>
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-green-400">
              +{marketData.change24h.toFixed(2)}%
            </span>
          </>
        ) : (
          <>
            <TrendingDown className="w-4 h-4 text-red-400" />
            <span className="text-red-400">
              {marketData.change24h.toFixed(2)}%
            </span>
          </>
        )}
      </div>
    </div>
  );
};