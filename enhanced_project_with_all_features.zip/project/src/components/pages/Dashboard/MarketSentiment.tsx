import React from 'react';
import { Brain, TrendingUp, Activity } from 'lucide-react';
import { useAI } from '../../../features/ai/hooks/useAI';

export const MarketSentiment: React.FC = () => {
  const { metrics } = useAI();

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex items-center gap-2 mb-6">
        <Brain className="w-5 h-5 text-blue-400" />
        <h2 className="text-lg font-semibold text-white">Market Sentiment</h2>
      </div>

      <div className="space-y-4">
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-400">Sentiment</span>
            <span className={`font-medium ${
              metrics.prediction === 'bullish' ? 'text-green-400' : 'text-red-400'
            }`}>
              {metrics.prediction.toUpperCase()}
            </span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div 
              className="bg-blue-500 rounded-full h-2"
              style={{ width: `${metrics.confidence * 100}%` }}
            />
          </div>
          <div className="text-right text-sm text-gray-400 mt-1">
            {(metrics.confidence * 100).toFixed(1)}% Confidence
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-gray-400">Volatility</span>
            </div>
            <span className="text-lg font-medium text-white">
              {(metrics.metrics.volatility * 100).toFixed(1)}%
            </span>
          </div>

          <div className="bg-gray-700 rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span className="text-sm text-gray-400">Momentum</span>
            </div>
            <span className="text-lg font-medium text-white">
              {(metrics.metrics.momentum * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};