import React from 'react';
import { useWallet } from '../../context/WalletContext';
import { useTrading } from '../../context/TradingContext';
import { Wallet, ArrowUpRight, ArrowDownRight } from 'lucide-react';

export const Portfolio: React.FC = () => {
  const { balance, address, transactions } = useWallet();
  const { positions } = useTrading();

  const totalPnL = positions.reduce((acc, pos) => acc + pos.pnl, 0);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-white mb-6">Portfolio</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Balance */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Balance</h2>
          <div className="text-3xl font-bold text-white">${balance.toFixed(2)}</div>
          <div className="text-sm text-gray-400 mt-1">
            {address ? `${address.slice(0, 6)}...${address.slice(-4)}` : 'Not Connected'}
          </div>
        </div>

        {/* PnL */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Profit/Loss</h2>
          <div className={`text-3xl font-bold ${totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {totalPnL >= 0 ? '+' : ''}{totalPnL.toFixed(2)}%
          </div>
          <div className="text-sm text-gray-400 mt-1">Overall Performance</div>
        </div>

        {/* Recent Transactions */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Recent Transactions</h2>
          <div className="space-y-4">
            {transactions.slice(0, 5).map(tx => (
              <div key={tx.id} className="flex items-center justify-between text-white">
                <div className="flex items-center gap-2">
                  {tx.amount >= 0 ? (
                    <ArrowUpRight className="w-4 h-4 text-green-400" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4 text-red-400" />
                  )}
                  <span>${Math.abs(tx.amount).toFixed(2)}</span>
                </div>
                <span className="text-sm text-gray-400">
                  {new Date(tx.timestamp).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};