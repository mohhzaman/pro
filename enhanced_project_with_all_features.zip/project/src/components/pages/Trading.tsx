import React, { useState } from 'react';
import { useTrading } from '../../features/trading/hooks/useTrading';
import { useAI } from '../../context/AIContext';
import { useWallet } from '../../context/WalletContext';
import { ArrowUpRight, ArrowDownRight, Wallet } from 'lucide-react';

export const Trading: React.FC = () => {
  const { createOrder, positions } = useTrading();
  const { metrics } = useAI();
  const { address, connect } = useWallet();
  const [isLoading, setIsLoading] = useState(false);

  const handleTrade = async (side: 'buy' | 'sell') => {
    if (!address) {
      try {
        await connect();
      } catch (error) {
        console.error('Failed to connect wallet:', error);
        return;
      }
    }

    try {
      setIsLoading(true);
      await createOrder({
        symbol: 'BTC/USD',
        type: 'market',
        side,
        amount: 1,
        timestamp: Date.now(),
        status: 'pending'
      });
    } catch (error) {
      console.error('Trading error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-white mb-6">Trading</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trading Actions */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Quick Trade</h2>
          {!address ? (
            <button
              onClick={() => connect()}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-500 disabled:opacity-50"
              disabled={isLoading}
            >
              <Wallet className="w-4 h-4" />
              Connect Wallet to Trade
            </button>
          ) : (
            <div className="flex gap-4">
              <button
                onClick={() => handleTrade('buy')}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-500 disabled:opacity-50"
                disabled={isLoading}
              >
                <ArrowUpRight className="w-4 h-4" />
                {isLoading ? 'Processing...' : 'Buy'}
              </button>
              <button
                onClick={() => handleTrade('sell')}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-500 disabled:opacity-50"
                disabled={isLoading}
              >
                <ArrowDownRight className="w-4 h-4" />
                {isLoading ? 'Processing...' : 'Sell'}
              </button>
            </div>
          )}
        </div>

        {/* AI Insights */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-white mb-4">AI Insights</h2>
          <div className="text-white">
            <div>Trend: {metrics.metrics.trend}</div>
            <div>Momentum: {(metrics.metrics.momentum * 100).toFixed(1)}%</div>
            <div>Volatility: {(metrics.metrics.volatility * 100).toFixed(1)}%</div>
          </div>
        </div>

        {/* Open Positions */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Open Positions</h2>
          {positions.length === 0 ? (
            <p className="text-gray-400">No open positions</p>
          ) : (
            positions.map(position => (
              <div key={position.id} className="mb-4 p-4 bg-gray-700 rounded-md">
                <div className="flex justify-between text-white">
                  <span>{position.symbol}</span>
                  <span className={position.pnl >= 0 ? 'text-green-400' : 'text-red-400'}>
                    {position.pnl.toFixed(2)}%
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};