import React from 'react';
import { useAI } from '../../context/AIContext';
import { useWallet } from '../../context/WalletContext';
import { useTrading } from '../../context/TradingContext';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { metrics } = useAI();
  const { balance, address } = useWallet();
  const { positions } = useTrading();

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-white mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Portfolio Overview */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Portfolio</h2>
          <div className="text-3xl font-bold text-white">${balance.toFixed(2)}</div>
          <div className="text-sm text-gray-400 mt-1">Total Balance</div>
        </div>

        {/* Market Sentiment */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Market Sentiment</h2>
          <div className="flex items-center">
            {metrics.prediction === 'bullish' ? (
              <TrendingUp className="w-6 h-6 text-green-400 mr-2" />
            ) : (
              <TrendingDown className="w-6 h-6 text-red-400 mr-2" />
            )}
            <span className="text-white capitalize">{metrics.prediction}</span>
          </div>
          <div className="text-sm text-gray-400 mt-1">
            Confidence: {(metrics.confidence * 100).toFixed(1)}%
          </div>
        </div>

        {/* Active Positions */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Active Positions</h2>
          <div className="text-3xl font-bold text-white">{positions.length}</div>
          <div className="text-sm text-gray-400 mt-1">Open Trades</div>
        </div>
      </div>
    </div>
  );
};