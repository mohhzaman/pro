import React from 'react';
import { Filter } from 'lucide-react';

interface MarketFiltersProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

const CATEGORIES = [
  'All',
  'Layer 1',
  'Layer 2',
  'DeFi',
  'Exchange',
  'Stablecoin',
  'Metaverse',
  'Gaming',
  'Web3',
  'Meme'
];

export const MarketFilters: React.FC<MarketFiltersProps> = ({
  selectedCategory,
  onCategoryChange
}) => {
  return (
    <div className="flex items-center gap-4 mb-6 overflow-x-auto pb-2">
      <Filter className="w-5 h-5 text-gray-400" />
      {CATEGORIES.map(category => (
        <button
          key={category}
          onClick={() => onCategoryChange(category)}
          className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap ${
            selectedCategory === category
              ? 'bg-blue-600 text-white'
              : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
          }`}
        >
          {category}
        </button>
      ))}
    </div>
  );
};