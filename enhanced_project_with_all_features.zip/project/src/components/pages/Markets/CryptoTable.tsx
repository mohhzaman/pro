import React, { useState } from 'react';
import { TrendingUp, TrendingDown, Search } from 'lucide-react';
import { CRYPTO_LIST } from '../../../features/market/constants/cryptoList';
import { useMarketData } from '../../../features/market/hooks/useMarketData';
import { formatCurrency, formatNumber } from '../../../utils/formatters';

export const CryptoTable: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'price' | 'change24h'>('price');
  const [sortDesc, setSortDesc] = useState(true);

  const filteredCryptos = CRYPTO_LIST.filter(crypto => 
    crypto.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    crypto.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-white">Cryptocurrency Markets</h2>
        <div className="relative">
          <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search cryptocurrencies..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-gray-700 text-white rounded-md pl-10 pr-4 py-2 w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="text-gray-400 border-b border-gray-700">
              <th className="px-6 py-3 text-left">Name</th>
              <th className="px-6 py-3 text-right">Price</th>
              <th className="px-6 py-3 text-right">24h Change</th>
              <th className="px-6 py-3 text-right">Market Cap</th>
              <th className="px-6 py-3 text-right">Volume (24h)</th>
            </tr>
          </thead>
          <tbody>
            {filteredCryptos.map((crypto) => (
              <CryptoRow key={crypto.symbol} crypto={crypto} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const CryptoRow: React.FC<{ crypto: typeof CRYPTO_LIST[0] }> = ({ crypto }) => {
  const { marketData } = useMarketData(`${crypto.symbol}/USD`);

  return (
    <tr className="border-b border-gray-700 hover:bg-gray-700/50">
      <td className="px-6 py-4">
        <div className="flex items-center">
          <div>
            <div className="font-medium text-white">{crypto.name}</div>
            <div className="text-sm text-gray-400">{crypto.symbol}</div>
          </div>
        </div>
      </td>
      <td className="px-6 py-4 text-right text-white">
        {formatCurrency(marketData.price)}
      </td>
      <td className="px-6 py-4 text-right">
        <div className="flex items-center justify-end">
          {marketData.change24h >= 0 ? (
            <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
          ) : (
            <TrendingDown className="w-4 h-4 text-red-400 mr-1" />
          )}
          <span className={marketData.change24h >= 0 ? 'text-green-400' : 'text-red-400'}>
            {marketData.change24h >= 0 ? '+' : ''}{marketData.change24h.toFixed(2)}%
          </span>
        </div>
      </td>
      <td className="px-6 py-4 text-right text-white">
        {formatNumber(marketData.marketCap)}
      </td>
      <td className="px-6 py-4 text-right text-white">
        {formatNumber(marketData.volume)}
      </td>
    </tr>
  );
};