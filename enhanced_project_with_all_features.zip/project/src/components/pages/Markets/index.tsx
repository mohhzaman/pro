import React, { useState } from 'react';
import { CryptoTable } from './CryptoTable';
import { MarketOverview } from '../Dashboard/MarketOverview';
import { MarketFilters } from './MarketFilters';
import { CRYPTO_LIST } from '../../../features/market/constants/cryptoList';

export const Markets: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  
  const filteredCryptos = selectedCategory === 'All'
    ? CRYPTO_LIST
    : CRYPTO_LIST.filter(crypto => crypto.category === selectedCategory);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white mb-6">Markets</h1>
      <MarketOverview />
      <MarketFilters 
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
      />
      <CryptoTable cryptos={filteredCryptos} />
    </div>
  );
};