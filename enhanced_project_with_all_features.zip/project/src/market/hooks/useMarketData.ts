import { useState, useEffect } from 'react';
import { MarketData } from '../../types/market';

export function useMarketData() {
  const [marketData, setMarketData] = useState<MarketData>({
    price: 0,
    volume: 0,
    timestamp: Date.now(),
    symbol: 'BTC/USD'
  });

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate market data updates
      setMarketData(prev => ({
        ...prev,
        price: prev.price + Math.random() * 100 - 50,
        volume: prev.volume + Math.random() * 1000,
        timestamp: Date.now()
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return { marketData };
}