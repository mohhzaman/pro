import React, { createContext, useContext, useState } from 'react';

interface AppState {
  theme: 'light' | 'dark';
  isAIAssistantVisible: boolean;
}

interface AppContextType extends AppState {
  toggleTheme: () => void;
  toggleAIAssistant: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>({
    theme: 'dark',
    isAIAssistantVisible: true
  });

  const toggleTheme = () => {
    setState(prev => ({
      ...prev,
      theme: prev.theme === 'light' ? 'dark' : 'light'
    }));
  };

  const toggleAIAssistant = () => {
    setState(prev => ({
      ...prev,
      isAIAssistantVisible: !prev.isAIAssistantVisible
    }));
  };

  return (
    <AppContext.Provider value={{
      ...state,
      toggleTheme,
      toggleAIAssistant
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};