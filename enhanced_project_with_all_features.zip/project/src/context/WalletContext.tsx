import React, { createContext, useContext, useState } from 'react';
import { WalletState, WalletTransaction } from '../types/wallet';
import { useWeb3 } from '../hooks/useWeb3';

interface WalletContextType {
  balance: number;
  address: string | null;
  transactions: WalletTransaction[];
  connect: () => Promise<void>;
  disconnect: () => void;
  sendTransaction: (to: string, amount: number) => Promise<void>;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [walletState, setWalletState] = useState<WalletState>({
    balance: 0,
    address: null,
    transactions: []
  });

  const { web3 } = useWeb3();

  const connect = async () => {
    try {
      const accounts = await web3.eth.requestAccounts();
      const balance = await web3.eth.getBalance(accounts[0]);
      setWalletState(prev => ({
        ...prev,
        address: accounts[0],
        balance: Number(web3.utils.fromWei(balance, 'ether'))
      }));
    } catch (error) {
      console.error('Failed to connect wallet:', error);
    }
  };

  const disconnect = () => {
    setWalletState({
      balance: 0,
      address: null,
      transactions: []
    });
  };

  const sendTransaction = async (to: string, amount: number) => {
    if (!walletState.address) throw new Error('Wallet not connected');
    // Implement transaction logic
  };

  return (
    <WalletContext.Provider value={{
      ...walletState,
      connect,
      disconnect,
      sendTransaction
    }}>
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within WalletProvider');
  }
  return context;
};