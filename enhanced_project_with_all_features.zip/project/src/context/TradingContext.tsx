import React, { createContext, useContext, useState } from 'react';
import { TradeOrder, TradePosition } from '../types/trading';
import { useWallet } from './WalletContext';
import { useMarketData } from '../market/hooks/useMarketData';

interface TradingContextType {
  positions: TradePosition[];
  orders: TradeOrder[];
  createOrder: (order: Omit<TradeOrder, 'id'>) => Promise<void>;
  closePosition: (positionId: string) => Promise<void>;
}

const TradingContext = createContext<TradingContextType | undefined>(undefined);

export const TradingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [positions, setPositions] = useState<TradePosition[]>([]);
  const [orders, setOrders] = useState<TradeOrder[]>([]);
  const { address } = useWallet();
  const { marketData } = useMarketData();

  const createOrder = async (order: Omit<TradeOrder, 'id'>) => {
    if (!address) throw new Error('Wallet not connected');
    const newOrder = {
      ...order,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      status: 'pending' as const
    };
    setOrders(prev => [...prev, newOrder]);
  };

  const closePosition = async (positionId: string) => {
    if (!address) throw new Error('Wallet not connected');
    setPositions(prev => prev.filter(pos => pos.id !== positionId));
  };

  return (
    <TradingContext.Provider value={{
      positions,
      orders,
      createOrder,
      closePosition
    }}>
      {children}
    </TradingContext.Provider>
  );
};

export const useTrading = () => {
  const context = useContext(TradingContext);
  if (!context) {
    throw new Error('useTrading must be used within TradingProvider');
  }
  return context;
};