import React, { createContext, useContext, useState } from 'react';
import { AIContextType } from '../features/ai/types';
import { useAIAnalysis } from '../features/ai/hooks/useAIAnalysis';
import { useAIRecommendations } from '../features/ai/hooks/useAIRecommendations';
import { AI_CONFIG } from '../features/ai/constants';

const AIContext = createContext<AIContextType | undefined>(undefined);

export const AIProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isVisible, setIsVisible] = useState(true);
  const { state, metrics } = useAIAnalysis();
  const { getRecommendation } = useAIRecommendations(metrics);

  const toggleVisibility = () => setIsVisible(prev => !prev);

  const value: AIContextType = {
    state,
    metrics,
    isVisible,
    config: AI_CONFIG,
    toggleVisibility,
    getRecommendation
  };

  return (
    <AIContext.Provider value={value}>
      {children}
    </AIContext.Provider>
  );
};

export const useAI = () => {
  const context = useContext(AIContext);
  if (!context) {
    throw new Error('useAI must be used within AIProvider');
  }
  return context;
};