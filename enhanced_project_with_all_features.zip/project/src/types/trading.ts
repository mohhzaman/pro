export interface TradeOrder {
  id: string;
  symbol: string;
  type: 'market' | 'limit';
  side: 'buy' | 'sell';
  amount: number;
  price?: number;
  timestamp: number;
  status: 'pending' | 'filled' | 'cancelled';
}

export interface TradePosition {
  id: string;
  symbol: string;
  side: 'long' | 'short';
  entryPrice: number;
  amount: number;
  leverage: number;
  timestamp: number;
  pnl: number;
}