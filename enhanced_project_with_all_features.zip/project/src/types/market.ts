export interface MarketData {
  price: number;
  volume: number;
  timestamp: number;
  symbol: string;
}

export interface MarketMetrics {
  volatility: number;
  momentum: number;
  trend: 'upward' | 'downward' | 'sideways';
}