export interface WalletState {
  balance: number;
  address: string | null;
  transactions: WalletTransaction[];
}

export interface WalletTransaction {
  id: string;
  from: string;
  to: string;
  amount: number;
  timestamp: number;
  status: 'pending' | 'completed' | 'failed';
}