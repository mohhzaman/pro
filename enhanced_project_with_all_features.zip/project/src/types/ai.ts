export interface AIState {
  intelligence: number;
  accuracy: number;
  knowledgeBase: Map<string, any>;
  lastPredictions: Array<any>;
}

export interface AIMetrics {
  confidence: number;
  prediction: string;
  metrics: {
    volatility: number;
    momentum: number;
    trend: string;
  };
}