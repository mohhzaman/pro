```typescript
import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { usePortfolio } from '../../../hooks/usePortfolio';
import { formatCurrency } from '../../../utils/formatters';

export const AssetAllocation: React.FC = () => {
  const { holdings } = usePortfolio();

  const data = {
    labels: holdings.map(h => h.symbol),
    datasets: [{
      data: holdings.map(h => h.value),
      backgroundColor: [
        'rgb(59, 130, 246)',
        'rgb(16, 185, 129)',
        'rgb(239, 68, 68)',
        'rgb(217, 119, 6)',
        'rgb(124, 58, 237)'
      ],
      borderWidth: 0
    }]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right' as const,
        labels: {
          color: '#fff',
          padding: 20
        }
      }
    }
  };

  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-6">Asset Allocation</h2>
      
      <div className="h-[300px]">
        <Doughnut data={data} options={options} />
      </div>

      <div className="mt-6 space-y-2">
        {holdings.map(holding => (
          <div
            key={holding.symbol}
            className="flex items-center justify-between bg-dark-100 rounded-lg p-3"
          >
            <div>
              <div className="font-medium text-white">{holding.symbol}</div>
              <div className="text-sm text-gray-400">{holding.amount} tokens</div>
            </div>
            <div className="text-right">
              <div className="text-white">{formatCurrency(holding.value)}</div>
              <div 
                className={
                  holding.change24h >= 0 ? 'text-sm text-green-400' : 'text-sm text-red-400'
                }
              >
                {holding.change24h >= 0 ? '+' : ''}
                {holding.change24h.toFixed(2)}%
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
```