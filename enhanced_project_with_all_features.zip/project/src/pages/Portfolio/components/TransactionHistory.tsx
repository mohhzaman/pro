```typescript
import React from 'react';
import { ArrowUpRight, ArrowDownRight, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { formatCurrency } from '../../../utils/formatters';

interface Transaction {
  id: string;
  type: 'buy' | 'sell';
  symbol: string;
  amount: number;
  price: number;
  timestamp: number;
}

export const TransactionHistory: React.FC = () => {
  // Simulated transaction data
  const transactions: Transaction[] = [
    {
      id: '1',
      type: 'buy',
      symbol: 'BTC',
      amount: 0.5,
      price: 45000,
      timestamp: Date.now() - 3600000
    },
    {
      id: '2',
      type: 'sell',
      symbol: 'ETH',
      amount: 2,
      price: 2500,
      timestamp: Date.now() - 7200000
    }
  ];

  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-6">Transaction History</h2>
      
      <div className="space-y-4">
        {transactions.map(tx => (
          <div
            key={tx.id}
            className="bg-dark-100 rounded-lg p-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              {tx.type === 'buy' ? (
                <ArrowDownRight className="w-8 h-8 text-green-400 bg-green-400/10 rounded-full p-1.5" />
              ) : (
                <ArrowUpRight className="w-8 h-8 text-red-400 bg-red-400/10 rounded-full p-1.5" />
              )}
              <div>
                <div className="font-medium text-white">
                  {tx.type === 'buy' ? 'Bought' : 'Sold'} {tx.amount} {tx.symbol}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Clock className="w-4 h-4" />
                  {formatDistanceToNow(tx.timestamp, { addSuffix: true })}
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-white">{formatCurrency(tx.amount * tx.price)}</div>
              <div className="text-sm text-gray-400">
                @ {formatCurrency(tx.price)}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
```