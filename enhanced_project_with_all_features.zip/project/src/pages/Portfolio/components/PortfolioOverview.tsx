```typescript
import React from 'react';
import { TrendingUp, TrendingDown, Wallet } from 'lucide-react';
import { useWallet } from '../../../hooks/useWallet';
import { usePortfolio } from '../../../hooks/usePortfolio';
import { formatCurrency } from '../../../utils/formatters';

export const PortfolioOverview: React.FC = () => {
  const { balance, address } = useWallet();
  const { performance } = usePortfolio();

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold text-white">Portfolio Overview</h2>
        <div className="flex items-center gap-2">
          <Wallet className="w-5 h-5 text-primary-400" />
          {address ? (
            <span className="text-sm text-gray-400">
              {address.slice(0, 6)}...{address.slice(-4)}
            </span>
          ) : (
            <span className="text-sm text-gray-400">Not Connected</span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-dark-100 rounded-lg p-4">
          <div className="text-sm text-gray-400 mb-1">Total Balance</div>
          <div className="text-2xl font-bold text-white">
            {formatCurrency(balance)}
          </div>
        </div>

        <div className="bg-dark-100 rounded-lg p-4">
          <div className="text-sm text-gray-400 mb-1">24h Change</div>
          <div className="flex items-center gap-1">
            {performance >= 0 ? (
              <>
                <TrendingUp className="w-4 h-4 text-green-400" />
                <span className="text-2xl font-bold text-green-400">
                  +{performance.toFixed(2)}%
                </span>
              </>
            ) : (
              <>
                <TrendingDown className="w-4 h-4 text-red-400" />
                <span className="text-2xl font-bold text-red-400">
                  {performance.toFixed(2)}%
                </span>
              </>
            )}
          </div>
        </div>

        <div className="bg-dark-100 rounded-lg p-4">
          <div className="text-sm text-gray-400 mb-1">Total Assets</div>
          <div className="text-2xl font-bold text-white">
            {formatCurrency(balance * (1 + performance / 100))}
          </div>
        </div>
      </div>
    </div>
  );
};
```