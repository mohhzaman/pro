```typescript
import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import { Button } from '../../../components/common/Button';

const TIME_PERIODS = [
  { label: '1D', days: 1 },
  { label: '1W', days: 7 },
  { label: '1M', days: 30 },
  { label: '3M', days: 90 },
  { label: '1Y', days: 365 }
];

export const PerformanceChart: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState(TIME_PERIODS[1]);

  // Simulated performance data
  const generateData = () => {
    const data = [];
    const points = 50;
    let value = 10000;
    
    for (let i = 0; i < points; i++) {
      value = value * (1 + (Math.random() - 0.5) * 0.02);
      data.push(value);
    }
    return data;
  };

  const data = {
    labels: Array.from({ length: 50 }, (_, i) => i),
    datasets: [{
      label: 'Portfolio Value',
      data: generateData(),
      borderColor: 'rgb(59, 130, 246)',
      backgroundColor: 'rgba(59, 130, 246, 0.1)',
      fill: true,
      tension: 0.4
    }]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          display: false
        }
      },
      y: {
        grid: {
          color: 'rgba(75, 85, 99, 0.1)'
        },
        ticks: {
          callback: (value: number) => 
            new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: 'USD',
              minimumFractionDigits: 0,
              maximumFractionDigits: 0
            }).format(value)
        }
      }
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold text-white">Performance</h2>
        <div className="flex gap-2">
          {TIME_PERIODS.map(period => (
            <Button
              key={period.label}
              variant={period === selectedPeriod ? 'primary' : 'secondary'}
              size="sm"
              onClick={() => setSelectedPeriod(period)}
            >
              {period.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="h-[300px]">
        <Line data={data} options={options} />
      </div>
    </div>
  );
};
```