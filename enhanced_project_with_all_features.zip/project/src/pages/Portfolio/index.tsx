import React from 'react';
import { PortfolioOverview } from './components/PortfolioOverview';
import { AssetAllocation } from './components/AssetAllocation';
import { TransactionHistory } from './components/TransactionHistory';
import { PerformanceChart } from './components/PerformanceChart';
import { Card } from '../../components/common/Card';

export const Portfolio: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Portfolio</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <PortfolioOverview />
          </Card>
        </div>
        <div>
          <Card>
            <AssetAllocation />
          </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <PerformanceChart />
        </Card>
        <Card>
          <TransactionHistory />
        </Card>
      </div>
    </div>
  );
};