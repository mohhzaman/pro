import React from 'react';
import { DiscussionBoard } from './components/DiscussionBoard';
import { TrendingTopics } from './components/TrendingTopics';
import { GroupList } from './components/GroupList';
import { Card } from '../../components/common/Card';

export const Community: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Community</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <DiscussionBoard />
          </Card>
        </div>
        <div className="space-y-6">
          <Card>
            <TrendingTopics />
          </Card>
          <Card>
            <GroupList />
          </Card>
        </div>
      </div>
    </div>
  );
};