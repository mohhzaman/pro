import React from 'react';
import { MessageSquare, ThumbsUp } from 'lucide-react';
import { Button } from '../../../components/common/Button';

export const DiscussionBoard: React.FC = () => {
  return (
    <div className="space-y-4">
      <div className="mb-6">
        <textarea
          placeholder="Start a discussion..."
          className="w-full bg-dark-100 text-white rounded-lg p-4 min-h-[100px] focus:outline-none focus:ring-2 focus:ring-primary-500"
        />
        <div className="flex justify-end mt-2">
          <Button variant="primary">Post</Button>
        </div>
      </div>

      <div className="space-y-4">
        {[1, 2, 3].map((post) => (
          <div key={post} className="bg-dark-100 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-10 h-10 rounded-full bg-dark-200" />
              <div>
                <div className="font-medium text-white">User{post}</div>
                <div className="text-sm text-gray-400">2 hours ago</div>
              </div>
            </div>
            <p className="text-gray-300 mb-4">
              This is a sample discussion post about crypto trading strategies...
            </p>
            <div className="flex items-center gap-4">
              <button className="flex items-center gap-1 text-gray-400 hover:text-white">
                <ThumbsUp className="w-4 h-4" />
                <span>24</span>
              </button>
              <button className="flex items-center gap-1 text-gray-400 hover:text-white">
                <MessageSquare className="w-4 h-4" />
                <span>12</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};