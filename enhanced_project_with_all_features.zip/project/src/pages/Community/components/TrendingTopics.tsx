import React from 'react';
import { TrendingUp } from 'lucide-react';

export const TrendingTopics: React.FC = () => {
  const topics = [
    { id: 1, name: 'Bitcoin ETF', posts: 156 },
    { id: 2, name: 'DeFi Yield Farming', posts: 89 },
    { id: 3, name: 'NFT Collections', posts: 67 }
  ];

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="w-5 h-5 text-primary-400" />
        <h2 className="text-lg font-semibold text-white">Trending Topics</h2>
      </div>
      <div className="space-y-3">
        {topics.map(topic => (
          <div
            key={topic.id}
            className="flex items-center justify-between bg-dark-100 rounded-lg p-3"
          >
            <span className="text-white">{topic.name}</span>
            <span className="text-sm text-gray-400">{topic.posts} posts</span>
          </div>
        ))}
      </div>
    </div>
  );
};