import React from 'react';
import { Users } from 'lucide-react';
import { Button } from '../../../components/common/Button';

export const GroupList: React.FC = () => {
  const groups = [
    { id: 1, name: 'Trading Strategies', members: 1234 },
    { id: 2, name: 'Technical Analysis', members: 856 },
    { id: 3, name: 'DeFi Discussion', members: 567 }
  ];

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Users className="w-5 h-5 text-primary-400" />
        <h2 className="text-lg font-semibold text-white">Popular Groups</h2>
      </div>
      <div className="space-y-3">
        {groups.map(group => (
          <div
            key={group.id}
            className="bg-dark-100 rounded-lg p-3"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-white">{group.name}</span>
              <span className="text-sm text-gray-400">{group.members} members</span>
            </div>
            <Button variant="outline" size="sm" className="w-full">
              Join Group
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
};