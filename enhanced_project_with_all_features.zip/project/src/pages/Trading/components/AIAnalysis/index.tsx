```typescript
import React from 'react';
import { Brain, TrendingUp, AlertTriangle } from 'lucide-react';
import { useAI } from '../../../../hooks/useAI';

export const AIAnalysis: React.FC = () => {
  const { metrics } = useAI();

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Brain className="w-5 h-5 text-primary-400" />
        <h2 className="text-lg font-semibold text-white">AI Analysis</h2>
      </div>

      <div className="space-y-4">
        <div className="bg-dark-100 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-primary-400" />
            <span className="text-white">Market Prediction</span>
          </div>
          <div className="text-gray-400">
            {metrics.prediction} ({(metrics.confidence * 100).toFixed(1)}% confidence)
          </div>
        </div>

        <div className="bg-dark-100 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <span className="text-white">Key Metrics</span>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Volatility</span>
              <span className="text-white">
                {(metrics.metrics.volatility * 100).toFixed(1)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Momentum</span>
              <span className="text-white">
                {(metrics.metrics.momentum * 100).toFixed(1)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Trend</span>
              <span className="text-white capitalize">
                {metrics.metrics.trend}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
```