```typescript
import React from 'react';
import { ArrowUpRight, ArrowDownRight, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { formatCurrency } from '../../../../utils/formatters';

export const TradingHistory: React.FC = () => {
  const trades = [
    {
      id: '1',
      symbol: 'BTC/USD',
      side: 'buy',
      amount: 0.5,
      price: 45000,
      total: 22500,
      timestamp: Date.now() - 3600000
    },
    {
      id: '2',
      symbol: 'ETH/USD',
      side: 'sell',
      amount: 2,
      price: 2500,
      total: 5000,
      timestamp: Date.now() - 7200000
    }
  ];

  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-4">Trading History</h2>
      
      <div className="space-y-4">
        {trades.map(trade => (
          <div key={trade.id} className="bg-dark-100 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                {trade.side === 'buy' ? (
                  <ArrowDownRight className="w-4 h-4 text-green-400" />
                ) : (
                  <ArrowUpRight className="w-4 h-4 text-red-400" />
                )}
                <div>
                  <div className="font-medium text-white">
                    {trade.side === 'buy' ? 'Bought' : 'Sold'} {trade.amount} {trade.symbol}
                  </div>
                  <div className="flex items-center gap-1 text-sm text-gray-400">
                    <Clock className="w-3 h-3" />
                    {formatDistanceToNow(trade.timestamp, { addSuffix: true })}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white">{formatCurrency(trade.total)}</div>
                <div className="text-sm text-gray-400">@ {formatCurrency(trade.price)}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
```