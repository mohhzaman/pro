```typescript
import React from 'react';
import { X } from 'lucide-react';
import { formatCurrency } from '../../../../utils/formatters';
import { Button } from '../../../../components/common/Button';

export const OpenOrders: React.FC = () => {
  const orders = [
    {
      id: '1',
      symbol: 'BTC/USD',
      type: 'limit',
      side: 'buy',
      amount: 0.5,
      price: 45000,
      total: 22500,
      filled: 0,
      status: 'open'
    }
  ];

  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-4">Open Orders</h2>
      
      {orders.length === 0 ? (
        <div className="text-gray-400">No open orders</div>
      ) : (
        <div className="space-y-4">
          {orders.map(order => (
            <div key={order.id} className="bg-dark-100 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <div>
                  <div className="font-medium text-white">{order.symbol}</div>
                  <div className="text-sm text-gray-400">
                    {order.type.toUpperCase()} • {order.side.toUpperCase()}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  icon={X}
                  className="text-gray-400 hover:text-white"
                />
              </div>
              <div className="grid grid-cols-3 gap-4 mt-2 text-sm">
                <div>
                  <div className="text-gray-400">Amount</div>
                  <div className="text-white">{order.amount}</div>
                </div>
                <div>
                  <div className="text-gray-400">Price</div>
                  <div className="text-white">{formatCurrency(order.price)}</div>
                </div>
                <div>
                  <div className="text-gray-400">Total</div>
                  <div className="text-white">{formatCurrency(order.total)}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
```