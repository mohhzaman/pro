```typescript
import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { formatCurrency } from '../../../../utils/formatters';

interface Order {
  price: number;
  amount: number;
  total: number;
}

interface OrderListProps {
  orders: Order[];
  type: 'asks' | 'bids';
}

export const OrderList: React.FC<OrderListProps> = ({ orders, type }) => {
  return (
    <div className="space-y-1">
      {orders.map((order, i) => (
        <div key={i} className="grid grid-cols-3 text-sm">
          <div className={`flex items-center ${
            type === 'asks' ? 'text-red-400' : 'text-green-400'
          }`}>
            {type === 'asks' ? (
              <ArrowUpRight className="w-3 h-3 mr-1" />
            ) : (
              <ArrowDownRight className="w-3 h-3 mr-1" />
            )}
            {formatCurrency(order.price)}
          </div>
          <div className="text-right text-gray-400">{order.amount.toFixed(4)}</div>
          <div className="text-right text-gray-400">{formatCurrency(order.total)}</div>
        </div>
      ))}
    </div>
  );
};
```