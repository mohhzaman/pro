```typescript
import React from 'react';
import { OrderList } from './OrderList';

export const OrderBook: React.FC = () => {
  // Simulated order book data
  const asks = [
    { price: 45100, amount: 2.5, total: 112750 },
    { price: 45200, amount: 1.8, total: 81360 },
    { price: 45300, amount: 3.2, total: 144960 }
  ];

  const bids = [
    { price: 45000, amount: 1.5, total: 67500 },
    { price: 44900, amount: 2.1, total: 94290 },
    { price: 44800, amount: 1.7, total: 76160 }
  ];

  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-4">Order Book</h2>
      
      <div className="grid grid-cols-3 text-sm text-gray-400 mb-2">
        <div>Price (USD)</div>
        <div className="text-right">Amount</div>
        <div className="text-right">Total</div>
      </div>

      <OrderList orders={asks} type="asks" />

      <div className="border-t border-b border-dark-100 py-2 my-2">
        <div className="text-lg text-white text-center font-medium">
          45,000.00
        </div>
      </div>

      <OrderList orders={bids} type="bids" />
    </div>
  );
};
```