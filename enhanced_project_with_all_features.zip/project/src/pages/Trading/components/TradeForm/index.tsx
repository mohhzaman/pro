```typescript
import React, { useState } from 'react';
import { useWallet } from '../../../../hooks/useWallet';
import { Button } from '../../../../components/common/Button';
import { ArrowUpRight, ArrowDownRight, Wallet } from 'lucide-react';

export const TradeForm: React.FC = () => {
  const { address, connect } = useWallet();
  const [amount, setAmount] = useState('');
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market');

  const handleTrade = async (side: 'buy' | 'sell') => {
    if (!address) {
      await connect();
      return;
    }
    // Implement trade execution
  };

  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-4">Place Order</h2>

      <div className="space-y-4">
        <div className="flex gap-2">
          <Button
            variant={orderType === 'market' ? 'primary' : 'secondary'}
            onClick={() => setOrderType('market')}
            className="flex-1"
          >
            Market
          </Button>
          <Button
            variant={orderType === 'limit' ? 'primary' : 'secondary'}
            onClick={() => setOrderType('limit')}
            className="flex-1"
          >
            Limit
          </Button>
        </div>

        <div>
          <label className="block text-sm text-gray-400 mb-1">Amount</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full bg-dark-100 text-white rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
            placeholder="0.00"
          />
        </div>

        {!address ? (
          <Button
            variant="primary"
            icon={Wallet}
            className="w-full"
            onClick={() => connect()}
          >
            Connect Wallet
          </Button>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="primary"
              icon={ArrowUpRight}
              onClick={() => handleTrade('buy')}
            >
              Buy
            </Button>
            <Button
              variant="secondary"
              icon={ArrowDownRight}
              onClick={() => handleTrade('sell')}
            >
              Sell
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
```