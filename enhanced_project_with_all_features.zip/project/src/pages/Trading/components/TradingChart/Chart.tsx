```typescript
import React from 'react';
import { Line } from 'react-chartjs-2';
import { useMarketData } from '../../../../hooks/useMarketData';
import { formatCurrency } from '../../../../utils/formatters';

export const Chart: React.FC = () => {
  const { marketData } = useMarketData();

  const data = {
    labels: Array.from({ length: 50 }, (_, i) => i),
    datasets: [{
      label: 'Price',
      data: Array.from({ length: 50 }, () => marketData.price + (Math.random() - 0.5) * 1000),
      borderColor: 'rgb(59, 130, 246)',
      backgroundColor: 'rgba(59, 130, 246, 0.1)',
      fill: true,
      tension: 0.4
    }]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        callbacks: {
          label: (context: any) => formatCurrency(context.raw)
        }
      }
    },
    scales: {
      x: {
        display: false
      },
      y: {
        grid: {
          color: 'rgba(75, 85, 99, 0.1)'
        },
        ticks: {
          callback: (value: number) => formatCurrency(value)
        }
      }
    }
  };

  return (
    <div className="h-[400px]">
      <Line data={data} options={options} />
    </div>
  );
};
```