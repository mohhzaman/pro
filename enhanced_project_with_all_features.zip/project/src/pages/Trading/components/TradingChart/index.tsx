```typescript
import React, { useState } from 'react';
import { Chart } from './Chart';
import { Controls } from './Controls';

export const TradingChart: React.FC = () => {
  const [interval, setInterval] = useState('15m');

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-white">Price Chart</h2>
        <Controls interval={interval} onIntervalChange={setInterval} />
      </div>
      <Chart />
    </div>
  );
};
```