```typescript
import React from 'react';
import { Button } from '../../../../components/common/Button';

const INTERVALS = ['1m', '5m', '15m', '1h', '4h', '1d'];

interface ControlsProps {
  interval: string;
  onIntervalChange: (interval: string) => void;
}

export const Controls: React.FC<ControlsProps> = ({ interval, onIntervalChange }) => {
  return (
    <div className="flex gap-2">
      {INTERVALS.map((i) => (
        <Button
          key={i}
          variant={interval === i ? 'primary' : 'secondary'}
          size="sm"
          onClick={() => onIntervalChange(i)}
        >
          {i}
        </Button>
      ))}
    </div>
  );
};
```