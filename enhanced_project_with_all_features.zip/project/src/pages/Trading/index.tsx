import React from 'react';
import { TradingChart } from './components/TradingChart';
import { OrderBook } from './components/OrderBook';
import { TradeForm } from './components/TradeForm';
import { OpenOrders } from './components/OpenOrders';
import { TradingHistory } from './components/TradingHistory';
import { AIAnalysis } from './components/AIAnalysis';
import { Card } from '../../components/common/Card';

export const Trading: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Trading</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-6">
          <Card>
            <TradingChart />
          </Card>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <OpenOrders />
            </Card>
            <Card>
              <TradingHistory />
            </Card>
          </div>
        </div>
        <div className="space-y-6">
          <Card>
            <TradeForm />
          </Card>
          <Card>
            <OrderBook />
          </Card>
          <Card>
            <AIAnalysis />
          </Card>
        </div>
      </div>
    </div>
  );
};