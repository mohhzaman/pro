import React, { useState } from 'react';
import { NewsGrid } from './components/NewsGrid';
import { NewsFilters } from './components/NewsFilters';
import { TrendingNews } from './components/TrendingNews';
import { useNews } from '../../hooks/useNews';
import { Card } from '../../components/common/Card';

export const News: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const { articles, isLoading } = useNews(selectedCategory);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Crypto News</h1>
      
      <Card>
        <TrendingNews articles={articles.slice(0, 3)} />
      </Card>
      
      <NewsFilters
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
      />
      
      <NewsGrid articles={articles} isLoading={isLoading} />
    </div>
  );
};