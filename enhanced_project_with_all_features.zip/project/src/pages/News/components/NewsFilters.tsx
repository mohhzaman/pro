import React from 'react';
import { Button } from '../../../components/common/Button';

const CATEGORIES = ['All', 'Bitcoin', 'Ethereum', 'DeFi', 'NFTs', 'Regulation'];

export const NewsFilters: React.FC = () => {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2">
      {CATEGORIES.map(category => (
        <Button
          key={category}
          variant="secondary"
          size="sm"
        >
          {category}
        </Button>
      ))}
    </div>
  );
};