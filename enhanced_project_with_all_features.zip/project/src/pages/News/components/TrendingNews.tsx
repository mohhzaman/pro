import React from 'react';
import { TrendingUp } from 'lucide-react';

interface NewsArticle {
  id: string;
  title: string;
  imageUrl: string;
  source: string;
}

interface TrendingNewsProps {
  articles: NewsArticle[];
}

export const TrendingNews: React.FC<TrendingNewsProps> = ({ articles }) => {
  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="w-5 h-5 text-primary-400" />
        <h2 className="text-lg font-semibold text-white">Trending News</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {articles.map(article => (
          <div key={article.id} className="relative group">
            <div className="relative h-48 rounded-lg overflow-hidden">
              <img
                src={article.imageUrl}
                alt={article.title}
                className="w-full h-full object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="text-white font-semibold line-clamp-2 group-hover:text-primary-400">
                  {article.title}
                </h3>
                <span className="text-sm text-gray-300">{article.source}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};