```typescript
import { useNews } from '../../../hooks';
import { Card } from '../../../components/common/Card';
// ... rest of the file remains the same
```