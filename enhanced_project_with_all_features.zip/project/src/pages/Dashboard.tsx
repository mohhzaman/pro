```tsx
import React from 'react';
import { useMarkets } from '../features/market';
import { MarketCard } from '../components/market/MarketCard';

export function Dashboard() {
  const { markets, isLoading } = useMarkets();

  if (isLoading) {
    return <div className="text-white">Loading...</div>;
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-white mb-6">Dashboard</h1>
      <div className="grid gap-6">
        {markets.map(market => (
          <MarketCard key={market.id} market={market} />
        ))}
      </div>
    </div>
  );
}
```