```typescript
import React from 'react';
import { CryptoTable } from './components/CryptoTable';
import { MarketOverview } from './components/MarketOverview';
import { MarketFilters } from './components/MarketFilters';
import { Card } from '../../components/common/Card';
import { useMarkets } from '../../features/market';

export const Markets: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Markets</h1>
      <Card>
        <MarketOverview />
      </Card>
      <MarketFilters />
      <CryptoTable />
    </div>
  );
};
```