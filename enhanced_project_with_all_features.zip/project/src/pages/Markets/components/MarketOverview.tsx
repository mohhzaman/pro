```typescript
import React from 'react';
import { TrendingUp, Activity, DollarSign, Percent } from 'lucide-react';
import { useMarkets } from '../../../features/market';
import { formatCurrency, formatNumber } from '../../../utils/formatters';

export const MarketOverview: React.FC = () => {
  const { globalData, isLoading } = useMarkets();

  // Rest of the component remains the same
  // ...
};
```