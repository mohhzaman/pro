import React from 'react';
import { Filter } from 'lucide-react';
import { Button } from '../../../components/common/Button';

const CATEGORIES = ['All', 'DeFi', 'Layer 1', 'Layer 2', 'NFTs', 'Meme'];

export const MarketFilters: React.FC = () => {
  return (
    <div className="flex items-center gap-4 overflow-x-auto pb-2">
      <Filter className="w-5 h-5 text-gray-400" />
      {CATEGORIES.map(category => (
        <Button
          key={category}
          variant="secondary"
          size="sm"
        >
          {category}
        </Button>
      ))}
    </div>
  );
};