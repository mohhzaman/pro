```typescript
import { useMarkets } from '../../../features/market/hooks/useMarkets';
import { Card } from '../../../components/common/Card';
import { Button } from '../../../components/common/Button';
// ... rest of the file remains the same
```