```typescript
import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { CoinOverview } from './components/CoinOverview';
import { PriceChart } from './components/PriceChart';
import { HighFrequencyChart } from '../../features/market/components/HighFrequencyChart';
import { MarketMetrics } from './components/MarketMetrics';
import { TradingView } from './components/TradingView';
import { OrderBook } from './components/OrderBook';
import { CoinNews } from './components/CoinNews';
import { SocialStats } from './components/SocialStats';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';

export const CoinDetails: React.FC = () => {
  const { coinId } = useParams<{ coinId: string }>();
  const [chartType, setChartType] = useState<'standard' | 'highFrequency'>('standard');

  return (
    <div className="space-y-6">
      <CoinOverview coinId={coinId!} />
      
      <div className="flex justify-end gap-2 mb-4">
        <Button
          variant={chartType === 'standard' ? 'primary' : 'secondary'}
          onClick={() => setChartType('standard')}
        >
          Standard Chart
        </Button>
        <Button
          variant={chartType === 'highFrequency' ? 'primary' : 'secondary'}
          onClick={() => setChartType('highFrequency')}
        >
          High Frequency
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            {chartType === 'standard' ? (
              <PriceChart coinId={coinId!} />
            ) : (
              <HighFrequencyChart symbol={coinId!} />
            )}
          </Card>
          <Card>
            <TradingView coinId={coinId!} />
          </Card>
        </div>
        <div className="space-y-6">
          <Card>
            <MarketMetrics coinId={coinId!} />
          </Card>
          <Card>
            <OrderBook coinId={coinId!} />
          </Card>
          <Card>
            <SocialStats coinId={coinId!} />
          </Card>
        </div>
      </div>

      <Card>
        <CoinNews coinId={coinId!} />
      </Card>
    </div>
  );
};
```