```tsx
import React from 'react';
import { Users, MessageSquare, Globe } from 'lucide-react';

interface SocialStatsProps {
  coinId: string;
}

export const SocialStats: React.FC<SocialStatsProps> = ({ coinId }) => {
  // Simulated social stats data
  const stats = {
    communityMembers: 245678,
    redditSubscribers: 123456,
    twitterFollowers: 567890,
    githubStars: 12345,
    websiteTraffic: 789012
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Users className="w-5 h-5 text-primary-400" />
        <h2 className="text-lg font-semibold text-white">Social Stats</h2>
      </div>

      <div className="space-y-4">
        <div className="bg-dark-100 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-primary-400" />
              <span className="text-gray-400">Community Members</span>
            </div>
            <span className="text-white font-medium">
              {stats.communityMembers.toLocaleString()}
            </span>
          </div>
        </div>

        <div className="bg-dark-100 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-primary-400" />
              <span className="text-gray-400">Reddit Subscribers</span>
            </div>
            <span className="text-white font-medium">
              {stats.redditSubscribers.toLocaleString()}
            </span>
          </div>
        </div>

        <div className="bg-dark-100 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-primary-400" />
              <span className="text-gray-400">Website Traffic</span>
            </div>
            <span className="text-white font-medium">
              {stats.websiteTraffic.toLocaleString()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
```