```tsx
import React from 'react';
import { TrendingUp, TrendingDown, Star } from 'lucide-react';
import { useMarketData } from '../../../features/market/hooks/useMarketData';
import { Button } from '../../../components/common/Button';
import { formatCurrency } from '../../../utils/formatters';

interface CoinOverviewProps {
  coinId: string;
}

export const CoinOverview: React.FC<CoinOverviewProps> = ({ coinId }) => {
  const { marketData } = useMarketData(coinId);

  return (
    <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
      <div className="flex items-center gap-4">
        <img
          src={`https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/128/color/${marketData.symbol.toLowerCase()}.png`}
          alt={marketData.name}
          className="w-12 h-12"
          onError={(e) => {
            e.currentTarget.src = 'https://via.placeholder.com/128?text=' + marketData.symbol;
          }}
        />
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-white">{marketData.name}</h1>
            <span className="text-gray-400">({marketData.symbol})</span>
            <Button variant="ghost" size="sm" icon={Star} />
          </div>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-2xl font-bold text-white">
              {formatCurrency(marketData.price)}
            </span>
            <div className={`flex items-center gap-1 ${
              marketData.change24h >= 0 ? 'text-green-400' : 'text-red-400'
            }`}>
              {marketData.change24h >= 0 ? (
                <TrendingUp className="w-4 h-4" />
              ) : (
                <TrendingDown className="w-4 h-4" />
              )}
              <span>{Math.abs(marketData.change24h).toFixed(2)}%</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-2">
        <Button variant="primary">Buy</Button>
        <Button variant="outline">Sell</Button>
        <Button variant="secondary">Trade</Button>
      </div>
    </div>
  );
};
```