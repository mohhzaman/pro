```tsx
import React from 'react';
import { TrendingUp, Activity, DollarSign } from 'lucide-react';
import { useMarketData } from '../../../features/market/hooks/useMarketData';
import { formatCurrency, formatNumber } from '../../../utils/formatters';

interface MarketMetricsProps {
  coinId: string;
}

export const MarketMetrics: React.FC<MarketMetricsProps> = ({ coinId }) => {
  const { marketData } = useMarketData(coinId);

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold text-white">Market Stats</h2>

      <div className="grid grid-cols-1 gap-4">
        <div className="bg-dark-100 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-4 h-4 text-primary-400" />
            <span className="text-gray-400">Market Cap</span>
          </div>
          <div className="text-xl font-bold text-white">
            {formatCurrency(marketData.marketCap)}
          </div>
          <div className="text-sm text-gray-400">
            Rank #{marketData.rank}
          </div>
        </div>

        <div className="bg-dark-100 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-primary-400" />
            <span className="text-gray-400">24h Volume</span>
          </div>
          <div className="text-xl font-bold text-white">
            {formatNumber(marketData.volume24h)}
          </div>
        </div>

        <div className="bg-dark-100 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-primary-400" />
            <span className="text-gray-400">Supply</span>
          </div>
          <div className="text-xl font-bold text-white">
            {formatNumber(marketData.circulatingSupply)} {marketData.symbol}
          </div>
          <div className="text-sm text-gray-400">
            Max Supply: {marketData.totalSupply ? formatNumber(marketData.totalSupply) : '∞'}
          </div>
        </div>
      </div>
    </div>
  );
};
```