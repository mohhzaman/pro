```tsx
import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import { Button } from '../../../components/common/Button';
import { useMarketChart } from '../../../features/market/hooks/useMarketChart';

interface PriceChartProps {
  coinId: string;
}

const TIME_PERIODS = [
  { label: '24H', days: 1 },
  { label: '7D', days: 7 },
  { label: '30D', days: 30 },
  { label: '90D', days: 90 },
  { label: '1Y', days: 365 }
];

export const PriceChart: React.FC<PriceChartProps> = ({ coinId }) => {
  const [selectedPeriod, setSelectedPeriod] = useState(TIME_PERIODS[1]);
  const { chartData, isLoading } = useMarketChart(coinId, selectedPeriod.days);

  if (isLoading) {
    return (
      <div className="h-[400px] flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary-500 border-t-transparent" />
      </div>
    );
  }

  const data = {
    labels: chartData.map(d => new Date(d.timestamp).toLocaleDateString()),
    datasets: [
      {
        label: 'Price',
        data: chartData.map(d => d.price),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        fill: true,
        tension: 0.4
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        grid: {
          color: 'rgba(75, 85, 99, 0.1)'
        }
      }
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-white">Price Chart</h2>
        <div className="flex gap-2">
          {TIME_PERIODS.map(period => (
            <Button
              key={period.label}
              variant={period === selectedPeriod ? 'primary' : 'secondary'}
              size="sm"
              onClick={() => setSelectedPeriod(period)}
            >
              {period.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="h-[400px]">
        <Line data={data} options={options} />
      </div>
    </div>
  );
};
```