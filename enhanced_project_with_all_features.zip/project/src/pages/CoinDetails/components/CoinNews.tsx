```tsx
import React from 'react';
import { Newspaper } from 'lucide-react';
import { useNews } from '../../../hooks/useNews';

interface CoinNewsProps {
  coinId: string;
}

export const CoinNews: React.FC<CoinNewsProps> = ({ coinId }) => {
  const { articles, isLoading } = useNews();

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-dark-100 h-24 rounded-lg" />
        ))}
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Newspaper className="w-5 h-5 text-primary-400" />
        <h2 className="text-lg font-semibold text-white">Latest News</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.slice(0, 6).map(article => (
          <a
            key={article.id}
            href={article.url}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-dark-100 rounded-lg overflow-hidden hover:bg-dark-200 transition-colors"
          >
            <img
              src={article.imageUrl}
              alt={article.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h3 className="text-white font-medium mb-2 line-clamp-2">
                {article.title}
              </h3>
              <div className="flex justify-between text-sm">
                <span className="text-primary-400">{article.source}</span>
                <span className="text-gray-400">2 hours ago</span>
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};
```