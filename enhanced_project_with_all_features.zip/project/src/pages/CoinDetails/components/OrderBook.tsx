```tsx
import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface OrderBookProps {
  coinId: string;
}

export const OrderBook: React.FC<OrderBookProps> = ({ coinId }) => {
  // Simulated order book data
  const asks = [
    { price: 45100, amount: 2.5 },
    { price: 45200, amount: 1.8 },
    { price: 45300, amount: 3.2 }
  ];

  const bids = [
    { price: 45000, amount: 1.5 },
    { price: 44900, amount: 2.1 },
    { price: 44800, amount: 1.7 }
  ];

  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-4">Order Book</h2>
      
      <div className="space-y-2">
        <div className="grid grid-cols-3 text-sm text-gray-400 mb-2">
          <div>Price (USD)</div>
          <div className="text-right">Amount</div>
          <div className="text-right">Total</div>
        </div>

        {/* Asks (Sell orders) */}
        <div className="space-y-1">
          {asks.map((order, i) => (
            <div
              key={`ask-${i}`}
              className="grid grid-cols-3 text-sm bg-dark-100/50"
            >
              <div className="text-red-400 flex items-center">
                <ArrowUpRight className="w-3 h-3 mr-1" />
                {order.price.toLocaleString()}
              </div>
              <div className="text-right">{order.amount}</div>
              <div className="text-right">
                {(order.price * order.amount).toLocaleString()}
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-b border-dark-100 py-2 my-2">
          <div className="text-lg text-white text-center font-medium">
            45,000.00
          </div>
        </div>

        {/* Bids (Buy orders) */}
        <div className="space-y-1">
          {bids.map((order, i) => (
            <div
              key={`bid-${i}`}
              className="grid grid-cols-3 text-sm bg-dark-100/50"
            >
              <div className="text-green-400 flex items-center">
                <ArrowDownRight className="w-3 h-3 mr-1" />
                {order.price.toLocaleString()}
              </div>
              <div className="text-right">{order.amount}</div>
              <div className="text-right">
                {(order.price * order.amount).toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
```