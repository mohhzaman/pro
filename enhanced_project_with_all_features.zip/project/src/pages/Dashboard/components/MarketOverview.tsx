import React from 'react';
import { TrendingUp, Activity, DollarSign } from 'lucide-react';
import { useMarkets } from '../../../features/market/hooks/useMarkets';
import { formatCurrency, formatNumber } from '../../../utils/formatters';

export const MarketOverview: React.FC = () => {
  const { globalData, isLoading } = useMarkets();

  if (isLoading || !globalData) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-dark-100 rounded-lg p-4 animate-pulse">
            <div className="h-4 bg-dark-200 rounded w-24 mb-2" />
            <div className="h-6 bg-dark-200 rounded w-32" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div>
        <div className="flex items-center gap-2 mb-2">
          <DollarSign className="w-5 h-5 text-primary-400" />
          <span className="text-gray-400">Total Market Cap</span>
        </div>
        <div className="text-2xl font-bold text-white">
          {formatCurrency(globalData.totalMarketCap)}
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2 mb-2">
          <Activity className="w-5 h-5 text-primary-400" />
          <span className="text-gray-400">24h Volume</span>
        </div>
        <div className="text-2xl font-bold text-white">
          {formatNumber(globalData.totalVolume24h)}
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2 mb-2">
          <TrendingUp className="w-5 h-5 text-primary-400" />
          <span className="text-gray-400">BTC Dominance</span>
        </div>
        <div className="text-2xl font-bold text-white">
          {globalData.btcDominance.toFixed(1)}%
        </div>
      </div>
    </div>
  );
};