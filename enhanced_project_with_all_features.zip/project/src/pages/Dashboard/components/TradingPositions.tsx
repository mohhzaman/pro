import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { useTrading } from '../../../hooks/useTrading';
import { formatCurrency } from '../../../utils/formatters';

export const TradingPositions: React.FC = () => {
  const { positions } = useTrading();

  if (positions.length === 0) {
    return (
      <div className="text-gray-400">No open positions</div>
    );
  }

  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-4">Open Positions</h2>
      <div className="space-y-4">
        {positions.map(position => (
          <div key={position.id} className="bg-dark-100 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <div>
                <div className="text-white font-medium">{position.symbol}</div>
                <div className="text-sm text-gray-400">
                  {position.side.toUpperCase()} @ {formatCurrency(position.entryPrice)}
                </div>
              </div>
              <div className={position.pnl >= 0 ? 'text-green-400' : 'text-red-400'}>
                {position.pnl >= 0 ? (
                  <TrendingUp className="w-4 h-4" />
                ) : (
                  <TrendingDown className="w-4 h-4" />
                )}
                {position.pnl.toFixed(2)}%
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};