import React from 'react';
import { Brain, TrendingUp } from 'lucide-react';
import { useAI } from '../../../hooks/useAI';

export const AIInsights: React.FC = () => {
  const { metrics } = useAI();

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Brain className="w-5 h-5 text-primary-400" />
        <h2 className="text-lg font-semibold text-white">AI Insights</h2>
      </div>
      
      <div className="space-y-4">
        <div className="bg-dark-100 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-primary-400" />
            <span className="text-white">Market Prediction</span>
          </div>
          <div className="text-gray-400">
            {metrics.prediction} ({(metrics.confidence * 100).toFixed(1)}% confidence)
          </div>
        </div>
      </div>
    </div>
  );
};