import React from 'react';
import { TrendingUp, TrendingDown, Wallet } from 'lucide-react';
import { useWallet } from '../../../hooks/useWallet';
import { formatCurrency } from '../../../utils/formatters';

export const PortfolioSummary: React.FC = () => {
  const { balance, address } = useWallet();
  const performance = 5.23; // Example value

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-white">Portfolio Summary</h2>
        <div className="flex items-center gap-2">
          <Wallet className="w-5 h-5 text-primary-400" />
          {address ? (
            <span className="text-sm text-gray-400">
              {address.slice(0, 6)}...{address.slice(-4)}
            </span>
          ) : (
            <span className="text-sm text-gray-400">Not Connected</span>
          )}
        </div>
      </div>
      
      <div className="text-3xl font-bold text-white mb-2">
        {formatCurrency(balance)}
      </div>
      <div className="flex items-center gap-1">
        {performance >= 0 ? (
          <>
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-green-400">+{performance}%</span>
          </>
        ) : (
          <>
            <TrendingDown className="w-4 h-4 text-red-400" />
            <span className="text-red-400">{performance}%</span>
          </>
        )}
        <span className="text-gray-400 text-sm">24h</span>
      </div>
    </div>
  );
};