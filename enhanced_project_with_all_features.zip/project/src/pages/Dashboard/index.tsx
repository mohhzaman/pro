```typescript
import React from 'react';
import { useMarkets } from '../../features/market';

export const Dashboard: React.FC = () => {
  const { markets, isLoading } = useMarkets();

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-white mb-6">Dashboard</h1>
      <div className="grid gap-6">
        {markets.map(market => (
          <div key={market.id} className="bg-dark-200 p-4 rounded-lg">
            <h2 className="text-white">{market.name}</h2>
            <p className="text-gray-400">${market.price.toLocaleString()}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
```