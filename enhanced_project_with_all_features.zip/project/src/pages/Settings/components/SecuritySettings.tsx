```typescript
import React from 'react';
import { Shield, Key, Smartphone } from 'lucide-react';
import { Button } from '../../../components/common/Button';

export const SecuritySettings: React.FC = () => {
  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-4">Security Settings</h2>
      
      <div className="space-y-6">
        <div>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Key className="w-5 h-5 text-primary-400" />
              <div>
                <div className="font-medium text-white">Password</div>
                <div className="text-sm text-gray-400">Last changed 30 days ago</div>
              </div>
            </div>
            <Button variant="secondary" size="sm">Change</Button>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-primary-400" />
              <div>
                <div className="font-medium text-white">Two-Factor Authentication</div>
                <div className="text-sm text-gray-400">Enhance your account security</div>
              </div>
            </div>
            <Button variant="primary" size="sm">Enable</Button>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary-400" />
              <div>
                <div className="font-medium text-white">Security Log</div>
                <div className="text-sm text-gray-400">View recent security activity</div>
              </div>
            </div>
            <Button variant="secondary" size="sm">View Log</Button>
          </div>
        </div>
      </div>
    </div>
  );
};
```