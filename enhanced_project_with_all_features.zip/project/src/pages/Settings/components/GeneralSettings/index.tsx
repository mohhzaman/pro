```typescript
import React from 'react';
import { Moon, Sun, Globe } from 'lucide-react';
import { Button } from '../../../../components/common/Button';

export const GeneralSettings: React.FC = () => {
  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-4">General Settings</h2>
      
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Theme
          </label>
          <div className="flex gap-2">
            <Button
              variant="secondary"
              size="sm"
              icon={Sun}
            >
              Light
            </Button>
            <Button
              variant="primary"
              size="sm"
              icon={Moon}
            >
              Dark
            </Button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Language
          </label>
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-gray-400" />
            <select className="bg-dark-100 text-white rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500">
              <option value="en">English</option>
              <option value="es">Español</option>
              <option value="fr">Français</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Currency
          </label>
          <select className="bg-dark-100 text-white rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500">
            <option value="usd">USD</option>
            <option value="eur">EUR</option>
            <option value="gbp">GBP</option>
          </select>
        </div>
      </div>
    </div>
  );
};
```