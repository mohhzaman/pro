```typescript
import React from 'react';
import { Key, Copy, RefreshCw } from 'lucide-react';
import { Button } from '../../../components/common/Button';

export const APISettings: React.FC = () => {
  const apiKey = "sk-1234...5678";

  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-4">API Settings</h2>
      
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            API Key
          </label>
          <div className="flex gap-2">
            <div className="flex-1 bg-dark-100 text-white rounded-md px-3 py-2 font-mono">
              {apiKey}
            </div>
            <Button
              variant="secondary"
              size="sm"
              icon={Copy}
              onClick={() => navigator.clipboard.writeText(apiKey)}
            >
              Copy
            </Button>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium text-white">Generate New Key</div>
              <div className="text-sm text-gray-400">
                This will invalidate your current API key
              </div>
            </div>
            <Button
              variant="primary"
              size="sm"
              icon={RefreshCw}
            >
              Generate
            </Button>
          </div>
        </div>

        <div className="bg-dark-100 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Key className="w-5 h-5 text-primary-400" />
            <span className="text-white font-medium">API Usage</span>
          </div>
          <div className="text-sm text-gray-400">
            <div className="flex justify-between mb-1">
              <span>Requests this month</span>
              <span>1,234 / 10,000</span>
            </div>
            <div className="w-full bg-dark-200 rounded-full h-2">
              <div className="bg-primary-500 h-2 rounded-full" style={{ width: '12%' }}></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
```