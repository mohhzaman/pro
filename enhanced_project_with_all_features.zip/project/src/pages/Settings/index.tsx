import React from 'react';
import { GeneralSettings } from './components/GeneralSettings';
import { SecuritySettings } from './components/SecuritySettings';
import { NotificationSettings } from './components/NotificationSettings';
import { APISettings } from './components/APISettings';
import { Card } from '../../components/common/Card';

export const Settings: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Settings</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <GeneralSettings />
        </Card>
        <Card>
          <SecuritySettings />
        </Card>
        <Card>
          <NotificationSettings />
        </Card>
        <Card>
          <APISettings />
        </Card>
      </div>
    </div>
  );
};