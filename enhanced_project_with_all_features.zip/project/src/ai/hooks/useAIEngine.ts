import { useEffect, useRef } from 'react';
import { AIEngine } from '../core/AIEngine';
import { useMarketData } from '../../market/hooks/useMarketData';

export function useAIEngine() {
  const engineRef = useRef<AIEngine>(new AIEngine());
  const { marketData } = useMarketData();

  useEffect(() => {
    const interval = setInterval(async () => {
      await engineRef.current.improve();
    }, 1);

    return () => clearInterval(interval);
  }, []);

  return {
    predict: async () => engineRef.current.predict(marketData),
    engine: engineRef.current
  };
}