import { AIState, AIMetrics } from '../types';
import { deepLearn } from '../utils/learning';
import { MarketData } from '../types/market';

export class AIEngine {
  private state: AIState;
  private learningRate: number = 0.001;
  private lastUpdate: number = Date.now();

  constructor() {
    this.state = {
      intelligence: 1.0,
      accuracy: 0.95,
      knowledgeBase: new Map(),
      lastPredictions: [],
    };
  }

  public async improve(): Promise<void> {
    const currentTime = Date.now();
    const timeDelta = currentTime - this.lastUpdate;
    
    // Improve every millisecond
    this.state.intelligence += (this.learningRate * timeDelta) / 1000;
    this.lastUpdate = currentTime;

    // Learn from recent predictions
    await this.learnFromPredictions();
  }

  private async learnFromPredictions(): Promise<void> {
    const accuracy = await this.calculateAccuracy();
    this.adjustLearningRate(accuracy);
  }

  private adjustLearningRate(accuracy: number): void {
    this.learningRate = Math.max(0.001, 0.01 * (1 - accuracy));
  }

  public async predict(data: MarketData): Promise<AIMetrics> {
    await this.improve();
    return deepLearn(data, this.state.intelligence);
  }
}