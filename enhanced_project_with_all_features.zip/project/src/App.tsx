```tsx
import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { Layout } from './components/Layout';
import { MarketProvider } from './features/market/context/MarketContext';

function App() {
  return (
    <Router>
      <MarketProvider>
        <Layout />
      </MarketProvider>
    </Router>
  );
}

export default App;
```