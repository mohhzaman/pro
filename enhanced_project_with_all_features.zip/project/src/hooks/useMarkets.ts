```tsx
import { useState, useEffect } from 'react';

interface Market {
  id: string;
  name: string;
  price: number;
}

export function useMarkets() {
  const [markets, setMarkets] = useState<Market[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulated API call
    setTimeout(() => {
      setMarkets([
        { id: 'bitcoin', name: 'Bitcoin', price: 45000 },
        { id: 'ethereum', name: 'Ethereum', price: 2500 }
      ]);
      setIsLoading(false);
    }, 1000);
  }, []);

  return { markets, isLoading };
}
```