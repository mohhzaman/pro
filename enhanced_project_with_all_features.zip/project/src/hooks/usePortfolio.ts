import { useState, useEffect } from 'react';
import { useMarketData } from '../features/market/hooks/useMarketData';

interface Holding {
  symbol: string;
  amount: number;
  value: number;
  change24h: number;
}

export const usePortfolio = () => {
  const [holdings, setHoldings] = useState<Holding[]>([
    { symbol: 'BTC', amount: 0.5, value: 0, change24h: 0 },
    { symbol: 'ETH', amount: 5, value: 0, change24h: 0 },
    { symbol: 'SOL', amount: 50, value: 0, change24h: 0 }
  ]);

  const [totalValue, setTotalValue] = useState(0);
  const [performance, setPerformance] = useState(0);

  // Update holdings values with live market data
  useEffect(() => {
    const updateHoldings = async () => {
      const updatedHoldings = await Promise.all(
        holdings.map(async holding => {
          const { marketData } = useMarketData(`${holding.symbol}/USD`);
          return {
            ...holding,
            value: holding.amount * marketData.price,
            change24h: marketData.change24h
          };
        })
      );

      setHoldings(updatedHoldings);
      
      const newTotalValue = updatedHoldings.reduce(
        (sum, holding) => sum + holding.value,
        0
      );
      setTotalValue(newTotalValue);

      const weightedPerformance = updatedHoldings.reduce(
        (sum, holding) => sum + (holding.change24h * holding.value / newTotalValue),
        0
      );
      setPerformance(weightedPerformance);
    };

    updateHoldings();
    const interval = setInterval(updateHoldings, 10000);
    return () => clearInterval(interval);
  }, []);

  return {
    holdings,
    totalValue,
    performance
  };
};