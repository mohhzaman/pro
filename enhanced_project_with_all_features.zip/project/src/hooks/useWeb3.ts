import { useState, useEffect } from 'react';
import Web3 from 'web3';

export function useWeb3() {
  const [web3, setWeb3] = useState<Web3 | null>(null);

  useEffect(() => {
    const initWeb3 = async () => {
      if (window.ethereum) {
        const web3Instance = new Web3(window.ethereum);
        setWeb3(web3Instance);
      }
    };

    initWeb3();
  }, []);

  return { web3: web3! };
}