import { useState, useEffect } from 'react';
import { MarketData } from '../features/market/types';

export const useMarketData = () => {
  const [marketData, setMarketData] = useState<MarketData>({
    id: 'btc',
    symbol: 'BTC',
    name: 'Bitcoin',
    price: 45000,
    change1h: 0,
    change24h: 2.5,
    change7d: 5.8,
    volume24h: 28000000000,
    marketCap: 850000000000,
    rank: 1,
    circulatingSupply: 19000000,
    totalSupply: 21000000,
    high24h: 46000,
    low24h: 44000,
    ath: 69000,
    athDate: '2021-11-10T14:24:11.849Z',
    category: 'Layer 1',
    updatedAt: Date.now()
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setMarketData(prev => ({
        ...prev,
        price: prev.price + (Math.random() - 0.5) * 1000,
        volume24h: prev.volume24h + Math.random() * 1000000000,
        change24h: prev.change24h + (Math.random() - 0.5),
        updatedAt: Date.now()
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return { marketData };
};