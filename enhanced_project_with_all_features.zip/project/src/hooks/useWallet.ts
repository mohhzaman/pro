import { useState, useCallback } from 'react';

export const useWallet = () => {
  const [address, setAddress] = useState<string | null>(null);
  const [balance, setBalance] = useState(0);

  const connect = useCallback(async () => {
    // Simulate wallet connection
    setAddress('0x1234...5678');
    setBalance(10000);
  }, []);

  const disconnect = useCallback(() => {
    setAddress(null);
    setBalance(0);
  }, []);

  return {
    address,
    balance,
    connect,
    disconnect
  };
};