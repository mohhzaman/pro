import { useState } from 'react';
import { TradePosition } from '../types/trading';

export const useTrading = () => {
  const [positions] = useState<TradePosition[]>([
    {
      id: '1',
      symbol: 'BTC/USD',
      side: 'long',
      entryPrice: 45000,
      amount: 1,
      leverage: 1,
      timestamp: Date.now(),
      pnl: 5.2
    }
  ]);

  return { positions };
};