import { useState, useCallback } from 'react';

const DEFAULT_FAVORITES = ['BTC', 'ETH', 'SOL', 'BNB', 'MATIC'];

export const useFavorites = () => {
  const [favorites, setFavorites] = useState<string[]>(DEFAULT_FAVORITES);

  const addFavorite = useCallback((symbol: string) => {
    setFavorites(prev => [...new Set([...prev, symbol])]);
  }, []);

  const removeFavorite = useCallback((symbol: string) => {
    setFavorites(prev => prev.filter(s => s !== symbol));
  }, []);

  const toggleFavorite = useCallback((symbol: string) => {
    setFavorites(prev => 
      prev.includes(symbol)
        ? prev.filter(s => s !== symbol)
        : [...prev, symbol]
    );
  }, []);

  return {
    favorites,
    addFavorite,
    removeFavorite,
    toggleFavorite
  };
};