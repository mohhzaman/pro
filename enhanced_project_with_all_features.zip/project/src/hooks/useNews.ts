import { useState, useEffect } from 'react';

interface NewsArticle {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  source: string;
  url: string;
}

export const useNews = () => {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchNews = async () => {
      setIsLoading(true);
      try {
        // Simulated news data
        const mockArticles: NewsArticle[] = [
          {
            id: '1',
            title: 'Bitcoin Reaches New All-Time High',
            description: 'The leading cryptocurrency continues its bullish trend...',
            imageUrl: 'https://source.unsplash.com/800x400/?bitcoin',
            source: 'CryptoNews',
            url: '#'
          },
          {
            id: '2',
            title: 'Ethereum 2.0 Update Shows Promise',
            description: 'The latest network upgrade improves scalability...',
            imageUrl: 'https://source.unsplash.com/800x400/?ethereum',
            source: 'BlockchainDaily',
            url: '#'
          },
          {
            id: '3',
            title: 'DeFi Market Cap Surpasses $100B',
            description: 'Decentralized finance continues to grow...',
            imageUrl: 'https://source.unsplash.com/800x400/?cryptocurrency',
            source: 'DeFiInsider',
            url: '#'
          }
        ];
        setArticles(mockArticles);
      } finally {
        setIsLoading(false);
      }
    };

    fetchNews();
  }, []);

  return { articles, isLoading };
};