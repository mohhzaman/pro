import { MarketData } from '../../market/types';
import { TradeOrder } from '../types';

export class TradingBot {
  private isRunning: boolean = false;
  private strategy: TradingStrategy;
  private symbol: string;
  private interval: number;
  private onOrder: (order: Omit<TradeOrder, 'id'>) => Promise<void>;

  constructor(
    symbol: string,
    strategy: TradingStrategy,
    interval: number = 5000,
    onOrder: (order: Omit<TradeOrder, 'id'>) => Promise<void>
  ) {
    this.symbol = symbol;
    this.strategy = strategy;
    this.interval = interval;
    this.onOrder = onOrder;
  }

  start() {
    this.isRunning = true;
    this.run();
  }

  stop() {
    this.isRunning = false;
  }

  private async run() {
    while (this.isRunning) {
      try {
        const signal = await this.strategy.analyze(this.symbol);
        if (signal) {
          await this.onOrder({
            symbol: this.symbol,
            type: 'market',
            side: signal.action,
            amount: signal.amount,
            timestamp: Date.now(),
            status: 'pending'
          });
        }
        await new Promise(resolve => setTimeout(resolve, this.interval));
      } catch (error) {
        console.error('Trading bot error:', error);
        this.stop();
      }
    }
  }
}

export interface TradingSignal {
  action: 'buy' | 'sell';
  amount: number;
  confidence: number;
}

export interface TradingStrategy {
  analyze(symbol: string): Promise<TradingSignal | null>;
}

export class SimpleMovingAverageStrategy implements TradingStrategy {
  private prices: number[] = [];
  private period: number;

  constructor(period: number = 20) {
    this.period = period;
  }

  async analyze(symbol: string): Promise<TradingSignal | null> {
    // Implement SMA strategy
    return null;
  }
}

export class RSIStrategy implements TradingStrategy {
  private period: number;
  private oversold: number;
  private overbought: number;

  constructor(period: number = 14, oversold: number = 30, overbought: number = 70) {
    this.period = period;
    this.oversold = oversold;
    this.overbought = overbought;
  }

  async analyze(symbol: string): Promise<TradingSignal | null> {
    // Implement RSI strategy
    return null;
  }
}