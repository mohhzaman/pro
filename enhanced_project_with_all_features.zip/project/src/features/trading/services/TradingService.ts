import { TradeOrder, TradePosition } from '../types';
import { MarketDataService } from '../../market/services/MarketDataService';

export class TradingService {
  private static instance: TradingService;
  
  private constructor() {}

  static getInstance(): TradingService {
    if (!TradingService.instance) {
      TradingService.instance = new TradingService();
    }
    return TradingService.instance;
  }

  async createOrder(order: Omit<TradeOrder, 'id'>): Promise<TradeOrder> {
    const id = crypto.randomUUID();
    return {
      ...order,
      id,
      timestamp: Date.now(),
      status: 'pending'
    };
  }

  async executeOrder(order: TradeOrder): Promise<TradePosition> {
    const marketService = MarketDataService.getInstance();
    const marketData = await marketService.fetchMarketData(order.symbol);

    return {
      id: crypto.randomUUID(),
      symbol: order.symbol,
      side: order.side === 'buy' ? 'long' : 'short',
      entryPrice: marketData.price,
      amount: order.amount,
      leverage: 1,
      timestamp: Date.now(),
      pnl: 0
    };
  }
}