import { useState } from 'react';
import { TradeOrder, TradePosition } from '../types';
import { TradingService } from '../services/TradingService';
import { useWallet } from '../../../context/WalletContext';

export function useTrading() {
  const [positions, setPositions] = useState<TradePosition[]>([]);
  const [orders, setOrders] = useState<TradeOrder[]>([]);
  const { address } = useWallet();
  const tradingService = TradingService.getInstance();

  const createOrder = async (orderData: Omit<TradeOrder, 'id'>) => {
    if (!address) throw new Error('Wallet not connected');

    const order = await tradingService.createOrder(orderData);
    setOrders(prev => [...prev, order]);

    const position = await tradingService.executeOrder(order);
    setPositions(prev => [...prev, position]);

    return position;
  };

  const closePosition = async (positionId: string) => {
    if (!address) throw new Error('Wallet not connected');
    setPositions(prev => prev.filter(pos => pos.id !== positionId));
  };

  return {
    positions,
    orders,
    createOrder,
    closePosition
  };
}