import { useState, useEffect } from 'react';
import { CopyTradingService } from '../services/CopyTradingService';

interface Trader {
  id: string;
  name: string;
  performance: number;
  winRate: number;
  followers: number;
}

export const useCopyTrading = () => {
  const [topTraders, setTopTraders] = useState<Trader[]>([]);
  const copyTradingService = CopyTradingService.getInstance();

  useEffect(() => {
    const loadTopTraders = async () => {
      const traders = await copyTradingService.getTopTraders();
      setTopTraders(traders);
    };

    loadTopTraders();
    const interval = setInterval(loadTopTraders, 300000);
    return () => clearInterval(interval);
  }, []);

  const followTrader = async (traderId: string) => {
    await copyTradingService.followTrader(traderId);
  };

  return {
    topTraders,
    followTrader
  };
};