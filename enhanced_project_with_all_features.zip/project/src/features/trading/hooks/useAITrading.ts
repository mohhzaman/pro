import { useState, useEffect } from 'react';
import { useMarketData } from '../../market/hooks/useMarketData';
import { AITradingService } from '../services/AITradingService';

export const useAITrading = () => {
  const [analysis, setAnalysis] = useState({
    summary: '',
    confidence: 0,
    sentiment: 'neutral'
  });
  
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const { marketData } = useMarketData();
  const aiService = AITradingService.getInstance();

  useEffect(() => {
    const updateAnalysis = async () => {
      const newAnalysis = await aiService.analyzeMarket(marketData);
      setAnalysis(newAnalysis);
      
      const newSuggestions = await aiService.generateSuggestions(newAnalysis);
      setSuggestions(newSuggestions);
    };

    updateAnalysis();
    const interval = setInterval(updateAnalysis, 60000);
    return () => clearInterval(interval);
  }, [marketData]);

  return {
    analysis,
    suggestions
  };
};