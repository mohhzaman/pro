import { useState, useCallback } from 'react';
import { TradingBot, TradingStrategy, SimpleMovingAverageStrategy, RSIStrategy } from '../bots/TradingBot';
import { useTrading } from './useTrading';

export const useTradingBot = (symbol: string) => {
  const [bot, setBot] = useState<TradingBot | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const { createOrder } = useTrading();

  const startBot = useCallback((strategyType: 'SMA' | 'RSI') => {
    if (bot) {
      stopBot();
    }

    const strategy: TradingStrategy = strategyType === 'SMA' 
      ? new SimpleMovingAverageStrategy()
      : new RSIStrategy();

    const newBot = new TradingBot(symbol, strategy, 5000, createOrder);
    newBot.start();
    setBot(newBot);
    setIsRunning(true);
  }, [symbol, createOrder]);

  const stopBot = useCallback(() => {
    if (bot) {
      bot.stop();
      setBot(null);
      setIsRunning(false);
    }
  }, [bot]);

  return {
    isRunning,
    startBot,
    stopBot
  };
};