import React from 'react';
import { Users, Star, TrendingUp } from 'lucide-react';
import { useCopyTrading } from '../../hooks/useCopyTrading';

export const CopyTrading: React.FC = () => {
  const { topTraders, followTrader } = useCopyTrading();

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex items-center gap-2 mb-4">
        <Users className="w-5 h-5 text-blue-400" />
        <h2 className="text-lg font-semibold text-white">Copy Trading</h2>
      </div>

      <div className="space-y-4">
        {topTraders.map(trader => (
          <div key={trader.id} className="bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-yellow-400" />
                <span className="text-white font-medium">{trader.name}</span>
              </div>
              <div className="flex items-center gap-1 text-green-400">
                <TrendingUp className="w-4 h-4" />
                <span>+{trader.performance}%</span>
              </div>
            </div>
            
            <div className="flex justify-between text-sm text-gray-400 mb-3">
              <span>Win Rate: {trader.winRate}%</span>
              <span>Followers: {trader.followers}</span>
            </div>

            <button
              onClick={() => followTrader(trader.id)}
              className="w-full py-2 bg-blue-600 text-white rounded-md hover:bg-blue-500"
            >
              Copy Trades
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};