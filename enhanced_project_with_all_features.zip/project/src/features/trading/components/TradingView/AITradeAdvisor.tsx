import React from 'react';
import { Brain, TrendingUp, AlertTriangle } from 'lucide-react';
import { useAITrading } from '../../hooks/useAITrading';

export const AITradeAdvisor: React.FC = () => {
  const { analysis, suggestions } = useAITrading();

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex items-center gap-2 mb-4">
        <Brain className="w-5 h-5 text-blue-400" />
        <h2 className="text-lg font-semibold text-white">AI Trade Advisor</h2>
      </div>

      <div className="space-y-4">
        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-white font-medium">Market Analysis</span>
          </div>
          <p className="text-gray-300">{analysis.summary}</p>
        </div>

        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <span className="text-white font-medium">Trade Suggestions</span>
          </div>
          <ul className="space-y-2">
            {suggestions.map((suggestion, index) => (
              <li key={index} className="text-gray-300">
                {suggestion}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};