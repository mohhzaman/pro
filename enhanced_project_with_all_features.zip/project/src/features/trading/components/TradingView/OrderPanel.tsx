import React, { useState } from 'react';
import { useTrading } from '../../hooks/useTrading';
import { OrderForm } from './OrderForm';
import { AdvancedOrderSettings } from './AdvancedOrderSettings';

export const OrderPanel: React.FC = () => {
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market');
  const [leverage, setLeverage] = useState(1);
  const { placeOrder } = useTrading();

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-lg font-semibold text-white mb-4">Place Order</h2>
      
      <div className="space-y-4">
        <div className="flex gap-2">
          <button
            onClick={() => setOrderType('market')}
            className={`flex-1 py-2 rounded-md ${
              orderType === 'market' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-700 text-gray-300'
            }`}
          >
            Market
          </button>
          <button
            onClick={() => setOrderType('limit')}
            className={`flex-1 py-2 rounded-md ${
              orderType === 'limit' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-700 text-gray-300'
            }`}
          >
            Limit
          </button>
        </div>

        <OrderForm type={orderType} leverage={leverage} />
        <AdvancedOrderSettings 
          leverage={leverage}
          onLeverageChange={setLeverage}
        />
      </div>
    </div>
  );
};