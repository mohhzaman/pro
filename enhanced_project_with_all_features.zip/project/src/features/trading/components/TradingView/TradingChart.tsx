import React, { useEffect, useRef } from 'react';
import { createChart, IChartApi } from 'lightweight-charts';
import { useMarketData } from '../../hooks/useMarketData';
import { TechnicalIndicators } from './TechnicalIndicators';

export const TradingChart: React.FC = () => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const { candlestickData } = useMarketData();

  useEffect(() => {
    if (chartContainerRef.current) {
      chartRef.current = createChart(chartContainerRef.current, {
        layout: {
          background: { color: '#1a1a1a' },
          textColor: '#d1d5db',
        },
        grid: {
          vertLines: { color: '#2d2d2d' },
          horzLines: { color: '#2d2d2d' },
        },
        width: chartContainerRef.current.clientWidth,
        height: 600,
      });

      const candlestickSeries = chartRef.current.addCandlestickSeries();
      candlestickSeries.setData(candlestickData);

      return () => {
        if (chartRef.current) {
          chartRef.current.remove();
        }
      };
    }
  }, [candlestickData]);

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-white">Price Chart</h2>
        <TechnicalIndicators />
      </div>
      <div ref={chartContainerRef} className="w-full" />
    </div>
  );
};