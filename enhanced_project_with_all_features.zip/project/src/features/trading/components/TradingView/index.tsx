import React from 'react';
import { TradingChart } from './TradingChart';
import { OrderPanel } from './OrderPanel';
import { TradingTools } from './TradingTools';
import { CopyTrading } from './CopyTrading';
import { AITradeAdvisor } from './AITradeAdvisor';

export const TradingView: React.FC = () => {
  return (
    <div className="grid grid-cols-12 gap-6">
      {/* Main Chart Area */}
      <div className="col-span-9">
        <TradingChart />
      </div>
      
      {/* Trading Panel */}
      <div className="col-span-3 space-y-6">
        <OrderPanel />
        <TradingTools />
        <CopyTrading />
        <AITradeAdvisor />
      </div>
    </div>
  );
};