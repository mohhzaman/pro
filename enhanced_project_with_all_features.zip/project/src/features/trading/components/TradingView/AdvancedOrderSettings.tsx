import React from 'react';
import { Sliders } from 'lucide-react';

interface AdvancedOrderSettingsProps {
  leverage: number;
  onLeverageChange: (leverage: number) => void;
}

export const AdvancedOrderSettings: React.FC<AdvancedOrderSettingsProps> = ({
  leverage,
  onLeverageChange
}) => {
  const leverageOptions = [1, 2, 5, 10, 20, 50, 100];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-gray-400">
        <Sliders className="w-4 h-4" />
        <span>Advanced Settings</span>
      </div>

      <div>
        <label className="block text-sm text-gray-400 mb-2">
          Leverage
        </label>
        <div className="flex gap-2">
          {leverageOptions.map(option => (
            <button
              key={option}
              onClick={() => onLeverageChange(option)}
              className={`px-3 py-1 rounded ${
                leverage === option
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-700 text-gray-400'
              }`}
            >
              {option}x
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm text-gray-400 mb-2">
          Stop Loss
        </label>
        <input
          type="number"
          className="w-full bg-gray-700 text-white rounded-md px-3 py-2"
          placeholder="Enter price"
        />
      </div>

      <div>
        <label className="block text-sm text-gray-400 mb-2">
          Take Profit
        </label>
        <input
          type="number"
          className="w-full bg-gray-700 text-white rounded-md px-3 py-2"
          placeholder="Enter price"
        />
      </div>

      <div>
        <label className="block text-sm text-gray-400 mb-2">
          Trailing Stop (%)
        </label>
        <input
          type="number"
          className="w-full bg-gray-700 text-white rounded-md px-3 py-2"
          placeholder="Enter percentage"
        />
      </div>
    </div>
  );
};