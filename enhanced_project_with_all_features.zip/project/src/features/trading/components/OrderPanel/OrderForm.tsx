import React, { useState } from 'react';
import { useTrading } from '../../hooks/useTrading';
import { useWallet } from '../../../../context/WalletContext';
import { ArrowUpRight, ArrowDownRight, Wallet } from 'lucide-react';

interface OrderFormProps {
  symbol: string;
}

export const OrderForm: React.FC<OrderFormProps> = ({ symbol }) => {
  const { createOrder } = useTrading();
  const { address, connect } = useWallet();
  const [amount, setAmount] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  const handleTrade = async (side: 'buy' | 'sell') => {
    if (!address) {
      try {
        await connect();
      } catch (error) {
        console.error('Failed to connect wallet:', error);
        return;
      }
    }

    if (!amount || isNaN(Number(amount))) return;

    try {
      setIsLoading(true);
      await createOrder({
        symbol,
        type: 'market',
        side,
        amount: Number(amount),
        timestamp: Date.now(),
        status: 'pending'
      });
    } catch (error) {
      console.error('Trading error:', error);
    } finally {
      setIsLoading(false);
      setAmount('');
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-lg font-semibold text-white mb-4">Place Order</h2>
      
      {!address ? (
        <button
          onClick={() => connect()}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-500"
        >
          <Wallet className="w-4 h-4" />
          Connect Wallet to Trade
        </button>
      ) : (
        <>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-400 mb-1">
              Amount ({symbol.split('/')[0]})
            </label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-gray-700 text-white rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="0.00"
              disabled={isLoading}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleTrade('buy')}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-500 disabled:opacity-50"
              disabled={isLoading || !amount}
            >
              <ArrowUpRight className="w-4 h-4" />
              {isLoading ? 'Processing...' : 'Buy'}
            </button>
            <button
              onClick={() => handleTrade('sell')}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-500 disabled:opacity-50"
              disabled={isLoading || !amount}
            >
              <ArrowDownRight className="w-4 h-4" />
              {isLoading ? 'Processing...' : 'Sell'}
            </button>
          </div>
        </>
      )}
    </div>
  );
};