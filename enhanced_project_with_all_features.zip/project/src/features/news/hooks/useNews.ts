import { useState, useEffect } from 'react';
import { NewsArticle } from '../types';
import { fetchNews } from '../api/newsApi';

export const useNews = (category?: string) => {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadNews = async () => {
      try {
        setIsLoading(true);
        const data = await fetchNews(category);
        setArticles(data);
        setError(null);
      } catch (err) {
        setError('Failed to load news');
        console.error('Error loading news:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadNews();
    const interval = setInterval(loadNews, 300000); // Refresh every 5 minutes
    return () => clearInterval(interval);
  }, [category]);

  return { articles, isLoading, error };
};