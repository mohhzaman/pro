import { NewsArticle } from '../types';

const API_KEY = process.env.VITE_NEWS_API_KEY;
const BASE_URL = 'https://newsapi.org/v2';

export const fetchNews = async (category: string = 'cryptocurrency'): Promise<NewsArticle[]> => {
  try {
    // For development, return simulated data if no API key
    if (!API_KEY) {
      return generateSimulatedNews();
    }

    const response = await fetch(
      `${BASE_URL}/everything?q=${category}&apiKey=${API_KEY}&sortBy=publishedAt`
    );
    
    if (!response.ok) {
      throw new Error('Failed to fetch news');
    }

    const data = await response.json();
    return data.articles.map(transformArticle);
  } catch (error) {
    console.error('Error fetching news:', error);
    return generateSimulatedNews();
  }
};

const transformArticle = (article: any): NewsArticle => ({
  id: crypto.randomUUID(),
  title: article.title,
  description: article.description,
  source: article.source.name,
  url: article.url,
  imageUrl: article.urlToImage,
  publishedAt: new Date(article.publishedAt),
  category: detectCategory(article.title)
});

const detectCategory = (title: string): string => {
  const keywords = {
    bitcoin: 'Bitcoin',
    ethereum: 'Ethereum',
    defi: 'DeFi',
    nft: 'NFT',
    regulation: 'Regulation',
    trading: 'Trading'
  };

  const lowercaseTitle = title.toLowerCase();
  for (const [keyword, category] of Object.entries(keywords)) {
    if (lowercaseTitle.includes(keyword)) {
      return category;
    }
  }
  return 'General';
};

const generateSimulatedNews = (): NewsArticle[] => {
  const news = [
    {
      title: 'Bitcoin Surges Past $50,000 as Institutional Interest Grows',
      description: 'Major financial institutions are increasing their cryptocurrency holdings...',
      source: 'CryptoNews',
      category: 'Bitcoin'
    },
    {
      title: 'New DeFi Protocol Launches with $100M TVL',
      description: 'A new decentralized finance protocol has attracted significant interest...',
      source: 'DeFi Daily',
      category: 'DeFi'
    },
    {
      title: 'Ethereum 2.0 Upgrade Shows Promising Results',
      description: 'The latest network upgrade has improved transaction speeds and reduced fees...',
      source: 'ETH News',
      category: 'Ethereum'
    }
  ];

  return news.map(article => ({
    id: crypto.randomUUID(),
    title: article.title,
    description: article.description,
    source: article.source,
    url: '#',
    imageUrl: `https://source.unsplash.com/800x400/?cryptocurrency,${article.category.toLowerCase()}`,
    publishedAt: new Date(),
    category: article.category
  }));
};