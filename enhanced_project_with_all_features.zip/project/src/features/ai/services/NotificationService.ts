type NotificationCallback = () => void;

export class NotificationService {
  private static instance: NotificationService;
  private subscribers: Set<NotificationCallback> = new Set();

  private constructor() {}

  static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService();
    }
    return NotificationService.instance;
  }

  subscribe(callback: NotificationCallback) {
    this.subscribers.add(callback);
  }

  unsubscribe(callback: NotificationCallback) {
    this.subscribers.delete(callback);
  }

  async sendNotification(message: string, type: string) {
    // Implement notification logic (email, Telegram, Discord)
    this.subscribers.forEach(callback => callback());
  }
}