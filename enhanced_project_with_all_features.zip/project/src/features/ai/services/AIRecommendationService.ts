import { AIMetrics } from '../types';

export class AIRecommendationService {
  private static instance: AIRecommendationService;
  
  private constructor() {}

  static getInstance(): AIRecommendationService {
    if (!AIRecommendationService.instance) {
      AIRecommendationService.instance = new AIRecommendationService();
    }
    return AIRecommendationService.instance;
  }

  async generateRecommendation(metrics: AIMetrics): Promise<string> {
    const { prediction, confidence, metrics: { trend, momentum, volatility } } = metrics;
    
    const riskLevel = this.calculateRiskLevel(volatility);
    const strengthIndicator = this.getStrengthIndicator(momentum);
    
    return `${prediction.toUpperCase()} signal detected with ${(confidence * 100).toFixed(1)}% confidence. ${strengthIndicator} ${trend} trend. Risk level: ${riskLevel}`;
  }

  private calculateRiskLevel(volatility: number): string {
    if (volatility > 0.6) return 'High';
    if (volatility > 0.3) return 'Medium';
    return 'Low';
  }

  private getStrengthIndicator(momentum: number): string {
    if (momentum > 0.7) return 'Strong';
    if (momentum > 0.4) return 'Moderate';
    return 'Weak';
  }
}