import { AIMetrics, AIState } from '../types';
import { MarketData } from '../../market/types';

export class AIAnalysisService {
  private static instance: AIAnalysisService;
  
  private constructor() {}

  static getInstance(): AIAnalysisService {
    if (!AIAnalysisService.instance) {
      AIAnalysisService.instance = new AIAnalysisService();
    }
    return AIAnalysisService.instance;
  }

  analyzeMarketData(data: MarketData, state: AIState): AIMetrics {
    const trend = this.analyzeTrend(data);
    const volatility = this.calculateVolatility(data);
    const momentum = this.calculateMomentum(data);
    
    return {
      confidence: Math.min(0.99, state.accuracy * (1 + state.intelligence / 100)),
      prediction: this.generatePrediction(trend, momentum),
      metrics: {
        volatility,
        momentum,
        trend
      }
    };
  }

  private analyzeTrend(data: MarketData): 'upward' | 'downward' | 'sideways' {
    // More sophisticated trend analysis
    const priceChange = data.price - (data.price * 0.9); // Simulated previous price
    if (Math.abs(priceChange) < data.price * 0.01) return 'sideways';
    return priceChange > 0 ? 'upward' : 'downward';
  }

  private calculateVolatility(data: MarketData): number {
    return Math.min(0.8, Math.abs(data.volume) / 10000);
  }

  private calculateMomentum(data: MarketData): number {
    return Math.min(0.9, Math.abs(data.volume) / 100000);
  }

  private generatePrediction(trend: string, momentum: number): string {
    if (trend === 'sideways') return 'neutral';
    if (momentum > 0.7) return trend === 'upward' ? 'strongly_bullish' : 'strongly_bearish';
    return trend === 'upward' ? 'bullish' : 'bearish';
  }
}