export interface AIAnalysis {
  prediction: string;
  confidence: number;
  summary: string;
  alerts: string[];
  recommendations: string[];
}

export interface Message {
  type: 'user' | 'assistant';
  content: string;
}

export interface AINotification {
  id: string;
  message: string;
  type: string;
  timestamp: number;
  read: boolean;
}