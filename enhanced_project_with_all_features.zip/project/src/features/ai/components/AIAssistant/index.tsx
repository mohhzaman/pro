import React, { useState } from 'react';
import { Brain, X } from 'lucide-react';
import { AIChat } from './AIChat';
import { AIAnalysis } from './AIAnalysis';
import { AINotifications } from './AINotifications';
import { Card } from '../../../../components/common/Card';
import { Button } from '../../../../components/common/Button';

export const AIAssistant: React.FC = () => {
  const [isMinimized, setIsMinimized] = useState(false);

  if (isMinimized) {
    return (
      <Button
        variant="primary"
        icon={Brain}
        className="fixed bottom-4 right-4 rounded-full shadow-lg"
        onClick={() => setIsMinimized(false)}
      >
        AI Assistant
      </Button>
    );
  }

  return (
    <Card className="fixed bottom-4 right-4 w-96 max-h-[80vh] flex flex-col shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-primary-400" />
          <h3 className="text-lg font-semibold text-white">AI Assistant</h3>
        </div>
        <div className="flex items-center gap-2">
          <AINotifications />
          <Button
            variant="ghost"
            size="sm"
            icon={X}
            onClick={() => setIsMinimized(true)}
          />
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        <AIAnalysis />
        <AIChat />
      </div>
    </Card>
  );
};