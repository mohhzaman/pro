import React from 'react';
import { Brain, TrendingUp, AlertTriangle, Heart } from 'lucide-react';
import { AIConfig } from '../../types';

interface AIHeaderProps {
  config: AIConfig;
}

export const AIHeader: React.FC<AIHeaderProps> = ({ config }) => {
  return (
    <div className="flex items-center justify-between mb-4">
      <h3 className="text-xl font-bold text-white">AI Assistant</h3>
      <div className="flex space-x-2">
        {config.emotionalAnalysis && (
          <Brain className="w-5 h-5 text-blue-400" />
        )}
        {config.tradingPsychology && (
          <Heart className="w-5 h-5 text-red-400" />
        )}
        {config.marketPredictions && (
          <TrendingUp className="w-5 h-5 text-green-400" />
        )}
        {config.personalizedAlerts && (
          <AlertTriangle className="w-5 h-5 text-yellow-400" />
        )}
      </div>
    </div>
  );
};