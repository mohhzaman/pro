import React from 'react';
import { TrendingUp, Brain, AlertTriangle } from 'lucide-react';
import { useAI } from '../../hooks/useAI';

export const AIAnalysis: React.FC = () => {
  const { analysis } = useAI();

  return (
    <div className="p-4 border-b border-gray-700">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-blue-400" />
            <span className="text-white font-medium">Market Analysis</span>
          </div>
          <span className="text-sm text-gray-400">
            {analysis.confidence}% Confidence
          </span>
        </div>

        <div className="bg-gray-700 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-white">Prediction: {analysis.prediction}</span>
          </div>
          <p className="text-gray-300 text-sm">{analysis.summary}</p>
        </div>

        {analysis.alerts.length > 0 && (
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-yellow-400" />
              <span className="text-white">Alerts</span>
            </div>
            <ul className="space-y-1">
              {analysis.alerts.map((alert, index) => (
                <li key={index} className="text-gray-300 text-sm">
                  {alert}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};