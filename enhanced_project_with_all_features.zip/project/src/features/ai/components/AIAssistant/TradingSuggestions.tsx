import React from 'react';
import { AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';
import { useAI } from '../../../../context/AIContext';

export const TradingSuggestions: React.FC = () => {
  const { metrics } = useAI();

  const getPredictionIcon = () => {
    switch (metrics.prediction) {
      case 'strongly_bullish':
      case 'bullish':
        return <TrendingUp className="w-5 h-5 text-green-400" />;
      case 'strongly_bearish':
      case 'bearish':
        return <TrendingDown className="w-5 h-5 text-red-400" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
    }
  };

  const getPredictionClass = () => {
    switch (metrics.prediction) {
      case 'strongly_bullish':
      case 'bullish':
        return 'text-green-400';
      case 'strongly_bearish':
      case 'bearish':
        return 'text-red-400';
      default:
        return 'text-yellow-400';
    }
  };

  return (
    <div className="bg-gray-700 rounded p-3">
      <div className="flex items-center gap-2">
        {getPredictionIcon()}
        <span className="text-white font-medium">Trading Suggestion</span>
      </div>
      <div className="mt-2">
        <div className={`font-semibold ${getPredictionClass()}`}>
          {metrics.prediction.replace('_', ' ').toUpperCase()}
        </div>
        <div className="text-white mt-1">
          <div>Confidence: {(metrics.confidence * 100).toFixed(1)}%</div>
          <div>Volatility: {(metrics.metrics.volatility * 100).toFixed(1)}%</div>
        </div>
      </div>
    </div>
  );
};