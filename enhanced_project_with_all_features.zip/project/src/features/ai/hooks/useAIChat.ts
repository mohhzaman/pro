import { useState, useCallback } from 'react';
import { AIService } from '../services/AIService';
import { Message } from '../types';

export const useAIChat = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const aiService = AIService.getInstance();

  const sendMessage = useCallback(async (content: string) => {
    setMessages(prev => [...prev, { type: 'user', content }]);
    setIsTyping(true);

    try {
      const response = await aiService.chat(content);
      setMessages(prev => [...prev, { type: 'assistant', content: response }]);
    } finally {
      setIsTyping(false);
    }
  }, []);

  return {
    messages,
    isTyping,
    sendMessage
  };
};