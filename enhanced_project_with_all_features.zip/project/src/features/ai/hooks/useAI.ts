import { useState, useEffect } from 'react';
import { AIService } from '../services/AIService';
import { AIAnalysis } from '../types';

export const useAI = () => {
  const [analysis, setAnalysis] = useState<AIAnalysis>({
    prediction: '',
    confidence: 0,
    summary: '',
    alerts: [],
    recommendations: []
  });

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const aiService = AIService.getInstance();

  useEffect(() => {
    const updateAnalysis = async () => {
      setIsAnalyzing(true);
      try {
        const newAnalysis = await aiService.analyze();
        setAnalysis(newAnalysis);
      } finally {
        setIsAnalyzing(false);
      }
    };

    updateAnalysis();
    const interval = setInterval(updateAnalysis, 60000);
    return () => clearInterval(interval);
  }, []);

  return {
    analysis,
    isAnalyzing
  };
};