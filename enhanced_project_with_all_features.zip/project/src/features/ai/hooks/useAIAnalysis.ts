import { useEffect, useState, useCallback } from 'react';
import { AIMetrics, AIState } from '../types';
import { useMarketData } from '../../market/hooks/useMarketData';
import { AI_INITIAL_METRICS, AI_INITIAL_STATE } from '../constants';
import { AIAnalysisService } from '../services/AIAnalysisService';

export const useAIAnalysis = () => {
  const [state, setState] = useState<AIState>(AI_INITIAL_STATE);
  const [metrics, setMetrics] = useState<AIMetrics>(AI_INITIAL_METRICS);
  const { marketData } = useMarketData();
  const analysisService = AIAnalysisService.getInstance();

  const improveAI = useCallback(() => {
    setState(prev => ({
      ...prev,
      intelligence: prev.intelligence * 1.001,
      accuracy: Math.min(0.99, prev.accuracy * 1.0001)
    }));
  }, []);

  const analyzeMarket = useCallback(() => {
    const newMetrics = analysisService.analyzeMarketData(marketData, state);
    setMetrics(newMetrics);
  }, [marketData, state]);

  // AI self-improvement loop
  useEffect(() => {
    const interval = setInterval(improveAI, 1000);
    return () => clearInterval(interval);
  }, [improveAI]);

  // Market analysis loop
  useEffect(() => {
    analyzeMarket();
  }, [analyzeMarket]);

  return { state, metrics };
};