import { useCallback } from 'react';
import { AIMetrics } from '../types';
import { AIRecommendationService } from '../services/AIRecommendationService';

export const useAIRecommendations = (metrics: AIMetrics) => {
  const recommendationService = AIRecommendationService.getInstance();

  const getRecommendation = useCallback(async () => {
    return recommendationService.generateRecommendation(metrics);
  }, [metrics]);

  return { getRecommendation };
};