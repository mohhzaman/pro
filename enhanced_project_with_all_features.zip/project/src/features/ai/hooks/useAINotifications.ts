import { useState, useEffect } from 'react';
import { AIService } from '../services/AIService';
import { NotificationService } from '../services/NotificationService';

export const useAINotifications = () => {
  const [unreadCount, setUnreadCount] = useState(0);
  const aiService = AIService.getInstance();
  const notificationService = NotificationService.getInstance();

  useEffect(() => {
    const handleNewNotification = () => {
      setUnreadCount(prev => prev + 1);
    };

    notificationService.subscribe(handleNewNotification);
    return () => notificationService.unsubscribe(handleNewNotification);
  }, []);

  const toggleNotifications = () => {
    setUnreadCount(0);
    // Implement notification panel toggle
  };

  return {
    unreadCount,
    toggleNotifications
  };
};