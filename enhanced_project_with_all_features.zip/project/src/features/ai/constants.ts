export const AI_CONFIG = {
  emotionalAnalysis: true,
  tradingPsychology: true,
  marketPredictions: true,
  personalizedAlerts: true
} as const;

export const AI_INITIAL_STATE = {
  intelligence: 1.0,
  accuracy: 0.95,
  knowledgeBase: new Map(),
  lastPredictions: []
} as const;

export const AI_INITIAL_METRICS = {
  confidence: 0.95,
  prediction: 'neutral',
  metrics: {
    volatility: 0.2,
    momentum: 0.5,
    trend: 'sideways'
  }
} as const;