import React from 'react';
import { TrendingUp } from 'lucide-react';
import { useAI } from '../../../context/AIContext';

export const MarketAnalysis: React.FC = () => {
  const { metrics } = useAI();

  return (
    <div className="bg-gray-700 rounded p-3">
      <div className="flex items-center gap-2">
        <TrendingUp className="w-5 h-5 text-green-400" />
        <span className="text-white font-medium">Market Analysis</span>
      </div>
      <div className="mt-2 text-white">
        <div>Trend: {metrics.metrics.trend}</div>
        <div>Confidence: {(metrics.confidence * 100).toFixed(1)}%</div>
        <div>Momentum: {(metrics.metrics.momentum * 100).toFixed(1)}%</div>
      </div>
    </div>
  );
};