import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { useAI } from '../../../context/AIContext';

export const TradingSuggestions: React.FC = () => {
  const { metrics } = useAI();

  return (
    <div className="bg-gray-700 rounded p-3">
      <div className="flex items-center gap-2">
        <AlertTriangle className="w-5 h-5 text-yellow-400" />
        <span className="text-white font-medium">Trading Suggestion</span>
      </div>
      <div className="mt-2 text-white">
        <div>Prediction: {metrics.prediction}</div>
        <div>Volatility: {(metrics.metrics.volatility * 100).toFixed(1)}%</div>
      </div>
    </div>
  );
};