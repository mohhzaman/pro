import React from 'react';
import { Brain } from 'lucide-react';
import { useAI } from '../../../context/AIContext';

export const AIMetrics: React.FC = () => {
  const { state } = useAI();

  return (
    <div className="bg-gray-700 rounded p-3">
      <div className="flex items-center gap-2">
        <Brain className="w-5 h-5 text-blue-400" />
        <span className="text-white font-medium">AI Intelligence Level</span>
      </div>
      <div className="mt-2 text-white">
        <div className="flex justify-between">
          <span>Intelligence:</span>
          <span>{state.intelligence.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span>Accuracy:</span>
          <span>{(state.accuracy * 100).toFixed(1)}%</span>
        </div>
      </div>
    </div>
  );
};