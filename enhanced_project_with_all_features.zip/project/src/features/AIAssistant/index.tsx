import React from 'react';
import { useAI } from '../../context/AIContext';
import { AIHeader } from './components/AIHeader';
import { AIMetrics } from './components/AIMetrics';
import { MarketAnalysis } from './components/MarketAnalysis';
import { TradingSuggestions } from './components/TradingSuggestions';

export const AIAssistant: React.FC = () => {
  const { config } = useAI();

  return (
    <div className="fixed bottom-4 right-4 w-96 bg-gray-800 rounded-lg shadow-lg p-4">
      <AIHeader config={config} />
      <div className="space-y-4">
        <AIMetrics />
        <MarketAnalysis />
        <TradingSuggestions />
      </div>
    </div>
  );
};