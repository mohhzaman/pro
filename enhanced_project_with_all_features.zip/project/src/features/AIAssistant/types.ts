export interface AIConfig {
  emotionalAnalysis: boolean;
  tradingPsychology: boolean;
  marketPredictions: boolean;
  personalizedAlerts: boolean;
}

export interface AIHeaderProps {
  config: AIConfig;
}