export interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal' | 'trade';
  amount: number;
  fee: number;
  timestamp: number;
  status: 'pending' | 'completed' | 'failed';
  hash: string;
}

export interface WalletBalance {
  total: number;
  available: number;
  locked: number;
}

export interface WalletAnalytics {
  totalFees: number;
  performance: number;
  volume: number;
  profitLoss: number;
}