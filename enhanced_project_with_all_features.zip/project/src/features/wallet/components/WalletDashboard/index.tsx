import React from 'react';
import { WalletBalance } from './WalletBalance';
import { TransactionHistory } from './TransactionHistory';
import { WalletAnalytics } from './WalletAnalytics';
import { TaxReports } from './TaxReports';

export const WalletDashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Wallet</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <WalletBalance />
        <WalletAnalytics />
      </div>
      <TransactionHistory />
      <TaxReports />
    </div>
  );
};