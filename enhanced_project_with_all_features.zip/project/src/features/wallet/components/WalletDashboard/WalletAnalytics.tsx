import React from 'react';
import { TrendingUp, PieChart, Activity } from 'lucide-react';
import { useWalletAnalytics } from '../../hooks/useWalletAnalytics';
import { formatCurrency } from '../../../../utils/formatters';

export const WalletAnalytics: React.FC = () => {
  const { totalFees, performance, volume } = useWalletAnalytics();

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-lg font-semibold text-white mb-4">Analytics</h2>
      
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-gray-400">Trading Volume</span>
          </div>
          <div className="text-xl font-semibold text-white">
            {formatCurrency(volume)}
          </div>
        </div>

        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-sm text-gray-400">Performance</span>
          </div>
          <div className="text-xl font-semibold text-green-400">
            +{performance.toFixed(2)}%
          </div>
        </div>

        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <PieChart className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-gray-400">Total Fees</span>
          </div>
          <div className="text-xl font-semibold text-white">
            {formatCurrency(totalFees)}
          </div>
        </div>
      </div>
    </div>
  );
};