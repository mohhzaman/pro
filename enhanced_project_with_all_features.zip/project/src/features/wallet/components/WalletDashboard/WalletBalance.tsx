import React from 'react';
import { Wallet, Plus, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { useWallet } from '../../hooks/useWallet';
import { formatCurrency } from '../../../../utils/formatters';

export const WalletBalance: React.FC = () => {
  const { balance, address, connectWallet, deposit, withdraw } = useWallet();

  if (!address) {
    return (
      <div className="bg-gray-800 rounded-lg p-6">
        <h2 className="text-lg font-semibold text-white mb-4">Connect Wallet</h2>
        <button
          onClick={connectWallet}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-500"
        >
          <Wallet className="w-4 h-4" />
          Connect Wallet
        </button>
      </div>
    );
  }

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold text-white">Wallet Balance</h2>
        <span className="text-sm text-gray-400">
          {address.slice(0, 6)}...{address.slice(-4)}
        </span>
      </div>

      <div className="text-3xl font-bold text-white mb-6">
        {formatCurrency(balance)}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <button
          onClick={() => deposit()}
          className="flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-500"
        >
          <Plus className="w-4 h-4" />
          Deposit
        </button>
        <button
          onClick={() => withdraw()}
          className="flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-500"
        >
          <ArrowUpRight className="w-4 h-4" />
          Withdraw
        </button>
      </div>
    </div>
  );
};