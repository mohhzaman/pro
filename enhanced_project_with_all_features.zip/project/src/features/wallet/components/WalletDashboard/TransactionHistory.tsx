import React from 'react';
import { Clock, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { useWallet } from '../../hooks/useWallet';
import { formatCurrency } from '../../../../utils/formatters';
import { formatDistanceToNow } from 'date-fns';

export const TransactionHistory: React.FC = () => {
  const { transactions } = useWallet();

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-lg font-semibold text-white mb-4">Transaction History</h2>
      
      <div className="space-y-4">
        {transactions.map(tx => (
          <div key={tx.id} className="bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                {tx.type === 'deposit' ? (
                  <ArrowDownLeft className="w-4 h-4 text-green-400" />
                ) : (
                  <ArrowUpRight className="w-4 h-4 text-red-400" />
                )}
                <div>
                  <div className="text-white font-medium">{tx.type}</div>
                  <div className="text-sm text-gray-400">
                    {formatDistanceToNow(tx.timestamp, { addSuffix: true })}
                  </div>
                </div>
              </div>
              <div className={tx.type === 'deposit' ? 'text-green-400' : 'text-red-400'}>
                {tx.type === 'deposit' ? '+' : '-'}{formatCurrency(tx.amount)}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};