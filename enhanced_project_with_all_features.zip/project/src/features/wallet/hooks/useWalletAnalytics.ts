import { useState, useEffect } from 'react';
import { useWallet } from './useWallet';
import { WalletAnalyticsService } from '../services/WalletAnalyticsService';

export const useWalletAnalytics = () => {
  const { address, transactions } = useWallet();
  const [analytics, setAnalytics] = useState({
    totalFees: 0,
    performance: 0,
    volume: 0
  });

  useEffect(() => {
    if (!address) return;

    const analyticsService = WalletAnalyticsService.getInstance();
    const calculateAnalytics = async () => {
      const data = await analyticsService.calculateMetrics(transactions);
      setAnalytics(data);
    };

    calculateAnalytics();
  }, [address, transactions]);

  return analytics;
};