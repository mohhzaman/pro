import { useState, useCallback } from 'react';
import { WalletService } from '../services/WalletService';
import { Transaction } from '../types';

export const useWallet = () => {
  const [address, setAddress] = useState<string | null>(null);
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const walletService = WalletService.getInstance();

  const connectWallet = useCallback(async () => {
    const { address, balance } = await walletService.connect();
    setAddress(address);
    setBalance(balance);
    const txHistory = await walletService.getTransactions(address);
    setTransactions(txHistory);
  }, []);

  const deposit = useCallback(async () => {
    if (!address) return;
    const { newBalance, transaction } = await walletService.deposit(address);
    setBalance(newBalance);
    setTransactions(prev => [transaction, ...prev]);
  }, [address]);

  const withdraw = useCallback(async () => {
    if (!address) return;
    const { newBalance, transaction } = await walletService.withdraw(address);
    setBalance(newBalance);
    setTransactions(prev => [transaction, ...prev]);
  }, [address]);

  return {
    address,
    balance,
    transactions,
    connectWallet,
    deposit,
    withdraw
  };
};