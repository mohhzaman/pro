export interface Profile {
  username: string;
  bio: string;
  location: string;
  avatar: string;
  website: string;
  followers: number;
  following: number;
}

export interface Discussion {
  id: string;
  content: string;
  author: {
    username: string;
    avatar: string;
  };
  timestamp: string;
  likes: number;
  comments: number;
}

export interface Group {
  id: string;
  name: string;
  description: string;
  members: number;
  avatar: string;
}