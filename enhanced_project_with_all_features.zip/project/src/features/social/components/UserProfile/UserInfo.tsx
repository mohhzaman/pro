import React from 'react';
import { User, Edit, MapPin, Link as LinkIcon } from 'lucide-react';
import { useProfile } from '../../hooks/useProfile';

export const UserInfo: React.FC = () => {
  const { profile, updateProfile } = useProfile();

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-full bg-gray-700 flex items-center justify-center">
            {profile.avatar ? (
              <img
                src={profile.avatar}
                alt={profile.username}
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <User className="w-8 h-8 text-gray-400" />
            )}
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">{profile.username}</h2>
            <div className="flex items-center gap-2 text-gray-400">
              <MapPin className="w-4 h-4" />
              <span>{profile.location}</span>
            </div>
          </div>
        </div>
        <button
          onClick={() => {/* Implement edit profile */}}
          className="text-gray-400 hover:text-white"
        >
          <Edit className="w-5 h-5" />
        </button>
      </div>

      <p className="text-gray-300 mb-4">{profile.bio}</p>

      {profile.website && (
        <div className="flex items-center gap-2 text-blue-400 hover:text-blue-300">
          <LinkIcon className="w-4 h-4" />
          <a href={profile.website} target="_blank" rel="noopener noreferrer">
            {profile.website}
          </a>
        </div>
      )}
    </div>
  );
};