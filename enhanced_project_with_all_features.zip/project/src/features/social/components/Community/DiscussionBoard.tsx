import React, { useState } from 'react';
import { MessageSquare, ThumbsUp, Share2 } from 'lucide-react';
import { useDiscussions } from '../../hooks/useDiscussions';

export const DiscussionBoard: React.FC = () => {
  const { discussions, createDiscussion } = useDiscussions();
  const [newPost, setNewPost] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPost.trim()) {
      createDiscussion(newPost);
      setNewPost('');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-800 rounded-lg p-6">
        <form onSubmit={handleSubmit}>
          <textarea
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            placeholder="Share your thoughts..."
            className="w-full bg-gray-700 text-white rounded-lg p-4 min-h-[100px] focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <div className="flex justify-end mt-4">
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-500"
            >
              Post
            </button>
          </div>
        </form>
      </div>

      <div className="space-y-4">
        {discussions.map(discussion => (
          <div key={discussion.id} className="bg-gray-800 rounded-lg p-6">
            <div className="flex items-start gap-4">
              <img
                src={discussion.author.avatar}
                alt={discussion.author.username}
                className="w-10 h-10 rounded-full"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-medium text-white">
                    {discussion.author.username}
                  </span>
                  <span className="text-sm text-gray-400">
                    {discussion.timestamp}
                  </span>
                </div>
                <p className="text-gray-300 mb-4">{discussion.content}</p>
                <div className="flex items-center gap-6">
                  <button className="flex items-center gap-2 text-gray-400 hover:text-white">
                    <ThumbsUp className="w-4 h-4" />
                    <span>{discussion.likes}</span>
                  </button>
                  <button className="flex items-center gap-2 text-gray-400 hover:text-white">
                    <MessageSquare className="w-4 h-4" />
                    <span>{discussion.comments}</span>
                  </button>
                  <button className="flex items-center gap-2 text-gray-400 hover:text-white">
                    <Share2 className="w-4 h-4" />
                    Share
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};