import React from 'react';
import { DiscussionBoard } from './DiscussionBoard';
import { TrendingTopics } from './TrendingTopics';
import { GroupList } from './GroupList';

export const Community: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Community</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <DiscussionBoard />
        </div>
        <div className="space-y-6">
          <TrendingTopics />
          <GroupList />
        </div>
      </div>
    </div>
  );
};