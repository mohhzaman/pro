import { useState, useEffect } from 'react';
import { Profile } from '../types';
import { SocialService } from '../services/SocialService';

export const useProfile = () => {
  const [profile, setProfile] = useState<Profile>({
    username: '',
    bio: '',
    location: '',
    avatar: '',
    website: '',
    followers: 0,
    following: 0
  });

  const socialService = SocialService.getInstance();

  useEffect(() => {
    const loadProfile = async () => {
      const data = await socialService.getProfile();
      setProfile(data);
    };

    loadProfile();
  }, []);

  const updateProfile = async (updates: Partial<Profile>) => {
    const updatedProfile = await socialService.updateProfile(updates);
    setProfile(updatedProfile);
  };

  return {
    profile,
    updateProfile
  };
};