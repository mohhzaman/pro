import { useState, useEffect } from 'react';
import { Discussion } from '../types';
import { SocialService } from '../services/SocialService';

export const useDiscussions = () => {
  const [discussions, setDiscussions] = useState<Discussion[]>([]);
  const socialService = SocialService.getInstance();

  useEffect(() => {
    const loadDiscussions = async () => {
      const data = await socialService.getDiscussions();
      setDiscussions(data);
    };

    loadDiscussions();
    const interval = setInterval(loadDiscussions, 30000);
    return () => clearInterval(interval);
  }, []);

  const createDiscussion = async (content: string) => {
    const newDiscussion = await socialService.createDiscussion(content);
    setDiscussions(prev => [newDiscussion, ...prev]);
  };

  return {
    discussions,
    createDiscussion
  };
};