import React from 'react';
import { useAI } from '../context/AIContext';
import { Brain, TrendingUp, AlertTriangle, Heart } from 'lucide-react';

export const AIAssistant: React.FC = () => {
  const { aiAssistant } = useAI();

  return (
    <div className="fixed bottom-4 right-4 w-96 bg-gray-800 rounded-lg shadow-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold text-white">AI Assistant</h3>
        <div className="flex space-x-2">
          {aiAssistant.config.emotionalAnalysis && (
            <Brain className="w-5 h-5 text-blue-400" />
          )}
          {aiAssistant.config.tradingPsychology && (
            <Heart className="w-5 h-5 text-red-400" />
          )}
          {aiAssistant.config.marketPredictions && (
            <TrendingUp className="w-5 h-5 text-green-400" />
          )}
          {aiAssistant.config.personalizedAlerts && (
            <AlertTriangle className="w-5 h-5 text-yellow-400" />
          )}
        </div>
      </div>
      <div className="space-y-4">
        <div className="bg-gray-700 rounded p-3">
          <p className="text-white">Market Analysis: Bullish trend detected in BTC/USD</p>
        </div>
        <div className="bg-gray-700 rounded p-3">
          <p className="text-white">Emotional State: Maintaining balanced trading psychology</p>
        </div>
        <div className="bg-gray-700 rounded p-3">
          <p className="text-white">Suggestion: Consider taking profits at $45,000</p>
        </div>
      </div>
    </div>
  );
};