```tsx
import React, { createContext, useContext, useReducer, useCallback, useEffect } from 'react';
import { MarketData, GlobalMarketData } from '../types';
import { fetchMarkets, fetchGlobalData } from '../api/marketApi';

interface MarketContextType {
  markets: MarketData[];
  globalData: GlobalMarketData | null;
  isLoading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
}

const MarketContext = createContext<MarketContextType | null>(null);

const initialState = {
  markets: [],
  globalData: null,
  isLoading: true,
  error: null
};

export function MarketProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(marketReducer, initialState);

  const refreshData = useCallback(async () => {
    try {
      dispatch({ type: 'FETCH_START' });
      const [markets, globalData] = await Promise.all([
        fetchMarkets(),
        fetchGlobalData()
      ]);
      dispatch({ type: 'FETCH_SUCCESS', markets, globalData });
    } catch (error) {
      dispatch({ type: 'FETCH_ERROR', error: 'Failed to fetch market data' });
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  return (
    <MarketContext.Provider value={{ ...state, refreshData }}>
      {children}
    </MarketContext.Provider>
  );
}

export function useMarketContext() {
  const context = useContext(MarketContext);
  if (!context) {
    throw new Error('useMarketContext must be used within MarketProvider');
  }
  return context;
}

type MarketAction =
  | { type: 'FETCH_START' }
  | { type: 'FETCH_SUCCESS'; markets: MarketData[]; globalData: GlobalMarketData }
  | { type: 'FETCH_ERROR'; error: string };

function marketReducer(state: typeof initialState, action: MarketAction) {
  switch (action.type) {
    case 'FETCH_START':
      return { ...state, isLoading: true, error: null };
    case 'FETCH_SUCCESS':
      return {
        ...state,
        markets: action.markets,
        globalData: action.globalData,
        isLoading: false,
        error: null
      };
    case 'FETCH_ERROR':
      return { ...state, isLoading: false, error: action.error };
    default:
      return state;
  }
}
```