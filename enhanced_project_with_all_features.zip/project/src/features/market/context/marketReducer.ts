```typescript
import { MarketData, GlobalMarketData } from '../types';

interface MarketState {
  markets: MarketData[];
  globalData: GlobalMarketData | null;
  isLoading: boolean;
  error: string | null;
}

type MarketAction =
  | { type: 'FETCH_START' }
  | { type: 'FETCH_SUCCESS'; markets: MarketData[]; globalData: GlobalMarketData }
  | { type: 'FETCH_ERROR'; error: string }
  | { type: 'UPDATE_MARKET'; market: MarketData };

export const initialState: MarketState = {
  markets: [],
  globalData: null,
  isLoading: true,
  error: null
};

export function marketReducer(state: MarketState, action: MarketAction): MarketState {
  switch (action.type) {
    case 'FETCH_START':
      return { ...state, isLoading: true, error: null };
    case 'FETCH_SUCCESS':
      return {
        ...state,
        markets: action.markets,
        globalData: action.globalData,
        isLoading: false,
        error: null
      };
    case 'FETCH_ERROR':
      return { ...state, isLoading: false, error: action.error };
    case 'UPDATE_MARKET':
      return {
        ...state,
        markets: state.markets.map(m => 
          m.id === action.market.id ? action.market : m
        )
      };
    default:
      return state;
  }
}
```