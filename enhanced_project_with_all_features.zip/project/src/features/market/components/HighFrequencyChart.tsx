```typescript
import React, { useEffect, useRef } from 'react';
import { Line } from 'react-chartjs-2';
import { useHighFrequencyData } from '../hooks/useHighFrequencyData';
import { Card } from '../../../components/common/Card';

interface HighFrequencyChartProps {
  symbol: string;
}

export const HighFrequencyChart: React.FC<HighFrequencyChartProps> = ({ symbol }) => {
  const { tickData } = useHighFrequencyData(symbol);
  const chartRef = useRef<any>(null);

  const data = {
    labels: tickData.map(tick => new Date(tick.timestamp).toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3
    })),
    datasets: [
      {
        label: `${symbol} Price`,
        data: tickData.map(tick => tick.price),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        fill: true,
        tension: 0.1
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
      duration: 0
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        mode: 'index',
        intersect: false
      }
    },
    scales: {
      x: {
        type: 'time',
        time: {
          unit: 'second',
          displayFormats: {
            second: 'HH:mm:ss.SSS'
          }
        },
        ticks: {
          maxRotation: 0,
          autoSkip: true,
          maxTicksLimit: 10
        }
      },
      y: {
        beginAtZero: false
      }
    }
  };

  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.update('none');
    }
  }, [tickData]);

  return (
    <Card>
      <div className="h-[400px]">
        <Line ref={chartRef} data={data} options={options} />
      </div>
    </Card>
  );
};
```