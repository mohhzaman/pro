import { MarketData } from '../types';

export class MarketDataService {
  private static instance: MarketDataService;
  
  private constructor() {}

  static getInstance(): MarketDataService {
    if (!MarketDataService.instance) {
      MarketDataService.instance = new MarketDataService();
    }
    return MarketDataService.instance;
  }

  async fetchMarketData(symbol: string): Promise<MarketData> {
    // Simulate real-time market data
    return {
      price: Math.random() * 50000 + 30000, // Random BTC price between 30k-80k
      volume: Math.random() * 1000000,
      timestamp: Date.now(),
      symbol
    };
  }

  calculateMetrics(data: MarketData) {
    return {
      volatility: Math.min(0.8, Math.abs(data.price - 45000) / 45000),
      momentum: Math.min(0.9, data.volume / 1000000),
      trend: data.price > 45000 ? 'upward' : 'downward'
    };
  }
}