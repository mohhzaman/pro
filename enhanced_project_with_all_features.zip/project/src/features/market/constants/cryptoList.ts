export const CRYPTO_LIST = [
  // Layer 1 Blockchains
  { symbol: 'BTC', name: 'Bitcoin', category: 'Layer 1' },
  { symbol: 'ETH', name: 'Ethereum', category: 'Layer 1' },
  { symbol: 'SOL', name: 'Solana', category: 'Layer 1' },
  { symbol: 'ADA', name: 'Cardano', category: 'Layer 1' },
  { symbol: 'AVAX', name: 'Avalanche', category: 'Layer 1' },
  { symbol: 'DOT', name: 'Polkadot', category: 'Layer 1' },
  { symbol: 'ATOM', name: 'Cosmos', category: 'Layer 1' },
  { symbol: 'NEAR', name: 'NEAR Protocol', category: 'Layer 1' },
  
  // Layer 2 Solutions
  { symbol: 'MATIC', name: 'Polygon', category: 'Layer 2' },
  { symbol: 'OP', name: 'Optimism', category: 'Layer 2' },
  { symbol: 'ARB', name: 'Arbitrum', category: 'Layer 2' },
  
  // DeFi
  { symbol: 'UNI', name: 'Uniswap', category: 'DeFi' },
  { symbol: 'AAVE', name: 'Aave', category: 'DeFi' },
  { symbol: 'MKR', name: 'Maker', category: 'DeFi' },
  { symbol: 'COMP', name: 'Compound', category: 'DeFi' },
  
  // Exchange Tokens
  { symbol: 'BNB', name: 'Binance Coin', category: 'Exchange' },
  { symbol: 'FTT', name: 'FTX Token', category: 'Exchange' },
  { symbol: 'CRO', name: 'Crypto.com Coin', category: 'Exchange' },
  
  // Stablecoins
  { symbol: 'USDT', name: 'Tether', category: 'Stablecoin' },
  { symbol: 'USDC', name: 'USD Coin', category: 'Stablecoin' },
  { symbol: 'DAI', name: 'Dai', category: 'Stablecoin' },
  
  // Gaming & Metaverse
  { symbol: 'SAND', name: 'The Sandbox', category: 'Metaverse' },
  { symbol: 'MANA', name: 'Decentraland', category: 'Metaverse' },
  { symbol: 'AXS', name: 'Axie Infinity', category: 'Gaming' },
  
  // Web3 & Infrastructure
  { symbol: 'LINK', name: 'Chainlink', category: 'Web3' },
  { symbol: 'GRT', name: 'The Graph', category: 'Web3' },
  { symbol: 'FIL', name: 'Filecoin', category: 'Storage' },
  
  // Meme Coins
  { symbol: 'DOGE', name: 'Dogecoin', category: 'Meme' },
  { symbol: 'SHIB', name: 'Shiba Inu', category: 'Meme' }
] as const;