// Extended list of supported cryptocurrencies with metadata
export const COIN_LIST = [
  // Layer 1 Blockchains
  { id: 'bitcoin', symbol: 'BTC', name: 'Bitcoin', category: 'Layer 1' },
  { id: 'ethereum', symbol: 'ETH', name: 'Ethereum', category: 'Layer 1' },
  { id: 'solana', symbol: 'SOL', name: 'Solana', category: 'Layer 1' },
  { id: 'cardano', symbol: 'ADA', name: 'Cardano', category: 'Layer 1' },
  { id: 'avalanche-2', symbol: 'AVAX', name: 'Avalanche', category: 'Layer 1' },
  { id: 'polkadot', symbol: 'DOT', name: 'Polkadot', category: 'Layer 1' },
  { id: 'cosmos', symbol: 'ATOM', name: 'Cosmos', category: 'Layer 1' },
  { id: 'near', symbol: 'NEAR', name: 'NEAR Protocol', category: 'Layer 1' },
  { id: 'tron', symbol: 'TRX', name: 'TRON', category: 'Layer 1' },
  { id: 'algorand', symbol: 'ALGO', name: 'Algorand', category: 'Layer 1' },

  // Layer 2 Solutions
  { id: 'matic-network', symbol: 'MATIC', name: 'Polygon', category: 'Layer 2' },
  { id: 'optimism', symbol: 'OP', name: 'Optimism', category: 'Layer 2' },
  { id: 'arbitrum', symbol: 'ARB', name: 'Arbitrum', category: 'Layer 2' },
  { id: 'loopring', symbol: 'LRC', name: 'Loopring', category: 'Layer 2' },
  { id: 'immutable-x', symbol: 'IMX', name: 'Immutable X', category: 'Layer 2' },

  // DeFi Protocols
  { id: 'uniswap', symbol: 'UNI', name: 'Uniswap', category: 'DeFi' },
  { id: 'aave', symbol: 'AAVE', name: 'Aave', category: 'DeFi' },
  { id: 'maker', symbol: 'MKR', name: 'Maker', category: 'DeFi' },
  { id: 'compound-governance-token', symbol: 'COMP', name: 'Compound', category: 'DeFi' },
  { id: 'curve-dao-token', symbol: 'CRV', name: 'Curve', category: 'DeFi' },
  { id: 'pancakeswap-token', symbol: 'CAKE', name: 'PancakeSwap', category: 'DeFi' },
  { id: 'sushi', symbol: 'SUSHI', name: 'SushiSwap', category: 'DeFi' },
  { id: '1inch', symbol: '1INCH', name: '1inch', category: 'DeFi' },
  { id: 'yearn-finance', symbol: 'YFI', name: 'Yearn Finance', category: 'DeFi' },
  { id: 'convex-finance', symbol: 'CVX', name: 'Convex Finance', category: 'DeFi' },

  // Exchange Tokens
  { id: 'binancecoin', symbol: 'BNB', name: 'BNB', category: 'Exchange' },
  { id: 'crypto-com-chain', symbol: 'CRO', name: 'Cronos', category: 'Exchange' },
  { id: 'kucoin-shares', symbol: 'KCS', name: 'KuCoin Token', category: 'Exchange' },
  { id: 'ftx-token', symbol: 'FTT', name: 'FTX Token', category: 'Exchange' },
  { id: 'huobi-token', symbol: 'HT', name: 'Huobi Token', category: 'Exchange' },

  // Stablecoins
  { id: 'tether', symbol: 'USDT', name: 'Tether', category: 'Stablecoin' },
  { id: 'usd-coin', symbol: 'USDC', name: 'USD Coin', category: 'Stablecoin' },
  { id: 'dai', symbol: 'DAI', name: 'Dai', category: 'Stablecoin' },
  { id: 'frax', symbol: 'FRAX', name: 'Frax', category: 'Stablecoin' },
  { id: 'true-usd', symbol: 'TUSD', name: 'TrueUSD', category: 'Stablecoin' },

  // Gaming & Metaverse
  { id: 'the-sandbox', symbol: 'SAND', name: 'The Sandbox', category: 'Metaverse' },
  { id: 'decentraland', symbol: 'MANA', name: 'Decentraland', category: 'Metaverse' },
  { id: 'axie-infinity', symbol: 'AXS', name: 'Axie Infinity', category: 'Gaming' },
  { id: 'gala', symbol: 'GALA', name: 'GALA', category: 'Gaming' },
  { id: 'enjincoin', symbol: 'ENJ', name: 'Enjin Coin', category: 'Gaming' },
  { id: 'illuvium', symbol: 'ILV', name: 'Illuvium', category: 'Gaming' },
  { id: 'stepn', symbol: 'GMT', name: 'STEPN', category: 'Gaming' },
  { id: 'render-token', symbol: 'RNDR', name: 'Render Token', category: 'Metaverse' },

  // Web3 Infrastructure
  { id: 'chainlink', symbol: 'LINK', name: 'Chainlink', category: 'Web3' },
  { id: 'the-graph', symbol: 'GRT', name: 'The Graph', category: 'Web3' },
  { id: 'filecoin', symbol: 'FIL', name: 'Filecoin', category: 'Web3' },
  { id: 'arweave', symbol: 'AR', name: 'Arweave', category: 'Web3' },
  { id: 'theta-token', symbol: 'THETA', name: 'Theta Network', category: 'Web3' },

  // AI & Computing
  { id: 'fetch-ai', symbol: 'FET', name: 'Fetch.ai', category: 'AI' },
  { id: 'singularitynet', symbol: 'AGIX', name: 'SingularityNET', category: 'AI' },
  { id: 'ocean-protocol', symbol: 'OCEAN', name: 'Ocean Protocol', category: 'AI' },
  { id: 'numeraire', symbol: 'NMR', name: 'Numeraire', category: 'AI' },

  // Meme Coins
  { id: 'dogecoin', symbol: 'DOGE', name: 'Dogecoin', category: 'Meme' },
  { id: 'shiba-inu', symbol: 'SHIB', name: 'Shiba Inu', category: 'Meme' },
  { id: 'pepe', symbol: 'PEPE', name: 'Pepe', category: 'Meme' },
  { id: 'floki', symbol: 'FLOKI', name: 'Floki Inu', category: 'Meme' }
] as const;

export const CATEGORIES = [
  'All',
  'Layer 1',
  'Layer 2',
  'DeFi',
  'Exchange',
  'Stablecoin',
  'Gaming',
  'Metaverse',
  'Web3',
  'AI',
  'Meme'
] as const;

export type CoinCategory = typeof CATEGORIES[number];