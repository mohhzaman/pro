```typescript
export { MarketProvider } from './context/MarketContext';
export { useMarkets } from './hooks/useMarkets';
export type { MarketData, GlobalMarketData } from './types';
```