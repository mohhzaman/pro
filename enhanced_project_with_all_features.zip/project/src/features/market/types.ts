```typescript
export interface MarketContextType {
  markets: MarketData[];
  globalData: GlobalMarketData | null;
  isLoading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
  updateMarket: (market: MarketData) => void;
}

export interface MarketData {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change1h: number;
  change24h: number;
  change7d: number;
  volume24h: number;
  marketCap: number;
  rank: number;
  circulatingSupply: number;
  totalSupply: number;
  high24h: number;
  low24h: number;
  ath: number;
  athDate: string;
  category: string;
  updatedAt: number;
}

export interface GlobalMarketData {
  totalMarketCap: number;
  totalVolume24h: number;
  btcDominance: number;
  ethDominance: number;
  defiMarketCap: number;
  totalCryptocurrencies: number;
  updatedAt: number;
}
```