```typescript
import { MarketData, GlobalMarketData } from '../types';

// Simulated API calls
export async function fetchMarkets(): Promise<MarketData[]> {
  return [
    {
      id: 'bitcoin',
      symbol: 'BTC',
      name: 'Bitcoin',
      price: 45000,
      change24h: 2.5,
      volume24h: 28000000000,
      marketCap: 850000000000,
      category: 'Layer 1'
    },
    // Add more mock data as needed
  ];
}

export async function fetchGlobalData(): Promise<GlobalMarketData> {
  return {
    totalMarketCap: 2000000000000,
    totalVolume24h: 100000000000,
    btcDominance: 40,
    ethDominance: 20
  };
}
```