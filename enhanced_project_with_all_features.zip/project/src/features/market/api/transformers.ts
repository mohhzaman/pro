import { MarketData, GlobalMarketData } from '../types';

export function transformMarketData(coin: any): MarketData {
  return {
    id: coin.id,
    symbol: coin.symbol.toUpperCase(),
    name: coin.name,
    price: coin.current_price || 0,
    change1h: coin.price_change_percentage_1h_in_currency || 0,
    change24h: coin.price_change_percentage_24h || 0,
    change7d: coin.price_change_percentage_7d_in_currency || 0,
    volume24h: coin.total_volume || 0,
    marketCap: coin.market_cap || 0,
    rank: coin.market_cap_rank || 999,
    circulatingSupply: coin.circulating_supply || 0,
    totalSupply: coin.total_supply || 0,
    high24h: coin.high_24h || 0,
    low24h: coin.low_24h || 0,
    ath: coin.ath || 0,
    athDate: coin.ath_date || '',
    category: getCoinCategory(coin),
    updatedAt: Date.now()
  };
}

function getCoinCategory(coin: any): string {
  const categories = new Map([
    ['cryptocurrency', 'Layer 1'],
    ['smart-contract-platform', 'Layer 1'],
    ['layer-2', 'Layer 2'],
    ['defi', 'DeFi'],
    ['exchange-based-tokens', 'Exchange'],
    ['meme-token', 'Meme'],
    ['gaming', 'Gaming'],
    ['metaverse', 'Metaverse']
  ]);

  const category = coin.categories?.[0]?.toLowerCase();
  return categories.get(category) || 'Other';
}

export function generateFallbackData(): MarketData[] {
  const topCoins = [
    { symbol: 'BTC', name: 'Bitcoin', price: 45000 },
    { symbol: 'ETH', name: 'Ethereum', price: 2500 },
    { symbol: 'BNB', name: 'BNB', price: 300 }
  ];

  return topCoins.map((coin, index) => ({
    id: coin.symbol.toLowerCase(),
    symbol: coin.symbol,
    name: coin.name,
    price: coin.price,
    change1h: 0,
    change24h: 0,
    change7d: 0,
    volume24h: 1000000000,
    marketCap: coin.price * 1000000,
    rank: index + 1,
    circulatingSupply: 1000000,
    totalSupply: 1000000,
    high24h: coin.price * 1.1,
    low24h: coin.price * 0.9,
    ath: coin.price * 1.5,
    athDate: new Date().toISOString(),
    category: 'Layer 1',
    updatedAt: Date.now()
  }));
}

export function generateFallbackGlobalData(): GlobalMarketData {
  return {
    totalMarketCap: 2000000000000,
    totalVolume24h: 100000000000,
    btcDominance: 40,
    ethDominance: 20,
    defiMarketCap: 50000000000,
    totalCryptocurrencies: 1000,
    updatedAt: Date.now()
  };
}