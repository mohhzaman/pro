import { API_CONFIG } from './apiConfig';
import { MarketData, GlobalMarketData } from '../types';
import { COIN_LIST } from '../constants/coinList';

class ApiClient {
  private static instance: ApiClient;
  private cache: Map<string, { data: any; timestamp: number }>;
  private retryCount: number = 0;
  private maxRetries: number = 3;
  private rateLimitDelay: number = 1000; // 1 second delay between requests

  private constructor() {
    this.cache = new Map();
  }

  static getInstance(): ApiClient {
    if (!ApiClient.instance) {
      ApiClient.instance = new ApiClient();
    }
    return ApiClient.instance;
  }

  private async fetchWithRetry<T>(
    url: string,
    options: RequestInit = {}
  ): Promise<T> {
    try {
      // Rate limiting
      await new Promise(resolve => setTimeout(resolve, this.rateLimitDelay));

      const response = await fetch(url, {
        ...options,
        headers: {
          'Accept': 'application/json',
          'Cache-Control': 'no-cache',
          ...options.headers
        }
      });

      if (response.status === 429) { // Rate limit exceeded
        const retryAfter = parseInt(response.headers.get('Retry-After') || '60');
        await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
        return this.fetchWithRetry(url, options);
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      this.retryCount = 0; // Reset retry count on success
      return data;
    } catch (error) {
      if (this.retryCount < this.maxRetries) {
        this.retryCount++;
        const delay = Math.pow(2, this.retryCount) * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
        return this.fetchWithRetry(url, options);
      }
      throw error;
    }
  }

  async getMarkets(): Promise<MarketData[]> {
    const cacheKey = 'markets';
    const cached = this.cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < API_CONFIG.cacheDuration) {
      return cached.data;
    }

    try {
      const url = new URL(`${API_CONFIG.baseUrl}/coins/markets`);
      url.search = new URLSearchParams({
        vs_currency: API_CONFIG.currency,
        order: 'market_cap_desc',
        per_page: API_CONFIG.perPage.toString(),
        sparkline: 'false',
        price_change_percentage: '1h,24h,7d',
        locale: 'en'
      }).toString();

      const data = await this.fetchWithRetry<any[]>(url.toString());
      const markets = data.map(this.transformMarketData);
      
      this.cache.set(cacheKey, { data: markets, timestamp: Date.now() });
      return markets;
    } catch (error) {
      console.warn('Using fallback market data:', error);
      return this.generateFallbackMarketData();
    }
  }

  async getGlobalData(): Promise<GlobalMarketData> {
    const cacheKey = 'global';
    const cached = this.cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < API_CONFIG.cacheDuration) {
      return cached.data;
    }

    try {
      const { data } = await this.fetchWithRetry<{ data: any }>(
        `${API_CONFIG.baseUrl}/global`
      );

      const globalData = {
        totalMarketCap: data.total_market_cap.usd || 0,
        totalVolume24h: data.total_volume.usd || 0,
        btcDominance: data.market_cap_percentage?.btc || 0,
        ethDominance: data.market_cap_percentage?.eth || 0,
        defiMarketCap: data.defi_market_cap || 0,
        totalCryptocurrencies: data.active_cryptocurrencies || 0,
        updatedAt: Date.now()
      };

      this.cache.set(cacheKey, { data: globalData, timestamp: Date.now() });
      return globalData;
    } catch (error) {
      console.warn('Using fallback global data:', error);
      return this.generateFallbackGlobalData();
    }
  }

  private transformMarketData(coin: any): MarketData {
    const coinInfo = COIN_LIST.find(c => c.id === coin.id);
    return {
      id: coin.id,
      symbol: coin.symbol.toUpperCase(),
      name: coin.name,
      price: coin.current_price || 0,
      change1h: coin.price_change_percentage_1h_in_currency || 0,
      change24h: coin.price_change_percentage_24h || 0,
      change7d: coin.price_change_percentage_7d_in_currency || 0,
      volume24h: coin.total_volume || 0,
      marketCap: coin.market_cap || 0,
      rank: coin.market_cap_rank || 999,
      circulatingSupply: coin.circulating_supply || 0,
      totalSupply: coin.total_supply || 0,
      high24h: coin.high_24h || 0,
      low24h: coin.low_24h || 0,
      ath: coin.ath || 0,
      athDate: coin.ath_date || '',
      category: coinInfo?.category || 'Other',
      updatedAt: Date.now()
    };
  }

  private generateFallbackMarketData(): MarketData[] {
    return COIN_LIST.map((coin, index) => ({
      id: coin.id,
      symbol: coin.symbol,
      name: coin.name,
      price: this.generateRealisticPrice(coin.symbol),
      change1h: (Math.random() - 0.5) * 5,
      change24h: (Math.random() - 0.5) * 10,
      change7d: (Math.random() - 0.5) * 20,
      volume24h: this.generateRealisticVolume(coin.symbol),
      marketCap: this.generateRealisticMarketCap(coin.symbol),
      rank: index + 1,
      circulatingSupply: this.generateRealisticSupply(coin.symbol),
      totalSupply: this.generateRealisticSupply(coin.symbol) * 1.2,
      high24h: 0,
      low24h: 0,
      ath: 0,
      athDate: new Date().toISOString(),
      category: coin.category,
      updatedAt: Date.now()
    }));
  }

  private generateRealisticPrice(symbol: string): number {
    const basePrices: Record<string, number> = {
      'BTC': 45000,
      'ETH': 2500,
      'BNB': 300,
      'SOL': 100,
      'ADA': 0.5,
      'DOT': 7,
      'MATIC': 1,
      'LINK': 15,
      'UNI': 5,
      'AAVE': 80
    };
    return (basePrices[symbol] || 1) * (0.9 + Math.random() * 0.2);
  }

  private generateRealisticVolume(symbol: string): number {
    const baseVolume = symbol === 'BTC' ? 20000000000 : 1000000000;
    return baseVolume * (0.5 + Math.random());
  }

  private generateRealisticMarketCap(symbol: string): number {
    const baseMarketCap = symbol === 'BTC' ? 1000000000000 : 10000000000;
    return baseMarketCap * (0.8 + Math.random() * 0.4);
  }

  private generateRealisticSupply(symbol: string): number {
    const baseSupply = symbol === 'BTC' ? 19000000 : 1000000000;
    return baseSupply * (0.9 + Math.random() * 0.2);
  }

  private generateFallbackGlobalData(): GlobalMarketData {
    return {
      totalMarketCap: 2000000000000,
      totalVolume24h: 100000000000,
      btcDominance: 40 + Math.random() * 10,
      ethDominance: 15 + Math.random() * 5,
      defiMarketCap: 50000000000,
      totalCryptocurrencies: COIN_LIST.length,
      updatedAt: Date.now()
    };
  }
}

export const apiClient = ApiClient.getInstance();