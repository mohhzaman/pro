export const API_CONFIG = {
  baseUrl: 'https://api.coingecko.com/api/v3',
  currency: 'usd',
  perPage: 250,
  updateInterval: 10000, // 10 seconds
  retryAttempts: 3,
  retryDelay: 1000,
  cacheDuration: 30000, // 30 seconds
  endpoints: {
    markets: '/coins/markets',
    global: '/global',
    chart: '/coins/{id}/market_chart',
    info: '/coins/{id}'
  },
  params: {
    markets: {
      vs_currency: 'usd',
      order: 'market_cap_desc',
      per_page: '250',
      sparkline: 'true',
      price_change_percentage: '1h,24h,7d'
    }
  }
} as const;

export const PRICE_WEBSOCKET_URL = 'wss://ws.coincap.io/prices?assets=ALL';