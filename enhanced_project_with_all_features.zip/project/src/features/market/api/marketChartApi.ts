import { MarketChartData } from '../types';

const COINGECKO_API_URL = 'https://api.coingecko.com/api/v3';

export async function fetchMarketChart(
  coinId: string,
  days: number = 7,
  interval?: string
): Promise<MarketChartData[]> {
  try {
    const params = new URLSearchParams({
      vs_currency: 'usd',
      days: days.toString(),
      ...(interval && { interval })
    });

    const response = await fetch(
      `${COINGECKO_API_URL}/coins/${coinId}/market_chart?${params}`
    );

    if (!response.ok) {
      throw new Error('Failed to fetch market chart data');
    }

    const data = await response.json();
    return data.prices.map(([timestamp, price]: [number, number]) => ({
      timestamp,
      price,
      volume: data.total_volumes.find((v: [number, number]) => v[0] === timestamp)?.[1] || 0
    }));
  } catch (error) {
    console.error('Error fetching market chart:', error);
    return [];
  }
}