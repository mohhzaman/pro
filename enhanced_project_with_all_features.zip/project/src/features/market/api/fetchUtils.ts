import { API_CONFIG, ApiError } from './apiConfig';

export async function fetchWithRetry<T>(
  url: string,
  options: RequestInit = {}
): Promise<T> {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt < API_CONFIG.retryAttempts; attempt++) {
    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          'Accept': 'application/json',
          ...options.headers
        }
      });

      if (!response.ok) {
        throw new ApiError(
          `HTTP error! status: ${response.status}`,
          response.status
        );
      }

      return await response.json();
    } catch (error) {
      lastError = error as Error;
      if (attempt < API_CONFIG.retryAttempts - 1) {
        await new Promise(resolve => 
          setTimeout(resolve, API_CONFIG.retryDelay * Math.pow(2, attempt))
        );
      }
    }
  }

  throw lastError || new Error('Failed to fetch data');
}