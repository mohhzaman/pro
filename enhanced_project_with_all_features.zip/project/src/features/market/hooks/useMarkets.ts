```tsx
import { useMarketContext } from '../context/MarketContext';

export function useMarkets() {
  const context = useMarketContext();
  return {
    markets: context.markets,
    isLoading: context.isLoading,
    error: context.error
  };
}
```