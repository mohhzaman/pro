import { useState, useEffect } from 'react';
import { useWebSocket } from './useWebSocket';
import { useMarketContext } from '../context/MarketContext';
import { MarketData } from '../types';
import { COIN_LIST } from '../constants/coinList';

export function useLiveMarketData() {
  const { markets, updateMarket } = useMarketContext();
  const { subscribe } = useWebSocket();
  const [lastUpdate, setLastUpdate] = useState<Record<string, number>>({});

  useEffect(() => {
    const unsubscribe = subscribe((data: Record<string, string>) => {
      Object.entries(data).forEach(([id, price]) => {
        const coin = COIN_LIST.find(c => c.id === id);
        if (coin && (!lastUpdate[id] || Date.now() - lastUpdate[id] > 1000)) {
          const market = markets.find(m => m.id === id);
          if (market) {
            const newPrice = parseFloat(price);
            const priceChange = ((newPrice - market.price) / market.price) * 100;
            
            updateMarket({
              ...market,
              price: newPrice,
              change1h: market.change1h + priceChange,
              updatedAt: Date.now()
            });

            setLastUpdate(prev => ({ ...prev, [id]: Date.now() }));
          }
        }
      });
    });

    return () => unsubscribe();
  }, [markets, subscribe, updateMarket, lastUpdate]);

  return markets;
}