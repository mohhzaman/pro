import { useState, useEffect } from 'react';
import { MarketData } from '../types';
import { COIN_LIST } from '../constants/coinList';
import { WebSocketService } from '../services/WebSocketService';

const PRICE_UPDATE_INTERVAL = 1000; // 1 second

export function useMarketData(symbol: string = 'BTC') {
  const [marketData, setMarketData] = useState<MarketData>(() => {
    const coin = COIN_LIST.find(c => c.symbol === symbol) || COIN_LIST[0];
    return {
      id: coin.id,
      symbol: coin.symbol,
      name: coin.name,
      price: getBasePrice(coin.symbol),
      change1h: 0,
      change24h: 0,
      change7d: 0,
      volume24h: getBaseVolume(coin.symbol),
      marketCap: getBaseMarketCap(coin.symbol),
      rank: 1,
      circulatingSupply: getBaseSupply(coin.symbol),
      totalSupply: getBaseSupply(coin.symbol) * 1.2,
      high24h: 0,
      low24h: 0,
      ath: 0,
      athDate: new Date().toISOString(),
      category: coin.category,
      updatedAt: Date.now()
    };
  });

  useEffect(() => {
    const ws = WebSocketService.getInstance();
    let lastUpdate = Date.now();

    const updatePrice = () => {
      const timeDiff = (Date.now() - lastUpdate) / 1000;
      const volatility = 0.002; // 0.2% base volatility
      const randomWalk = (Math.random() - 0.5) * 2 * volatility;
      const trendBias = Math.sin(Date.now() / 10000) * volatility; // Adds a slight trend
      const priceChange = (randomWalk + trendBias) * marketData.price;

      setMarketData(prev => {
        const newPrice = prev.price + priceChange;
        const newHigh = Math.max(prev.high24h, newPrice);
        const newLow = prev.low24h === 0 ? newPrice : Math.min(prev.low24h, newPrice);
        const volumeChange = (Math.random() * 0.1 + 0.95) * prev.volume24h;
        
        // Calculate rolling changes
        const change1h = ((newPrice - prev.price) / prev.price) * 100;
        const change24h = ((newPrice - prev.price * 0.98) / (prev.price * 0.98)) * 100;
        const change7d = ((newPrice - prev.price * 0.95) / (prev.price * 0.95)) * 100;

        return {
          ...prev,
          price: newPrice,
          high24h: newHigh,
          low24h: newLow,
          change1h: prev.change1h + change1h * timeDiff / 3600,
          change24h: change24h,
          change7d: change7d,
          volume24h: volumeChange,
          marketCap: newPrice * prev.circulatingSupply,
          updatedAt: Date.now()
        };
      });

      lastUpdate = Date.now();
    };

    const interval = setInterval(updatePrice, PRICE_UPDATE_INTERVAL);
    return () => clearInterval(interval);
  }, [marketData.price]);

  return { marketData };
}

function getBasePrice(symbol: string): number {
  const basePrices: Record<string, number> = {
    'BTC': 45000,
    'ETH': 2500,
    'BNB': 300,
    'SOL': 100,
    'ADA': 0.5,
    'DOT': 7,
    'MATIC': 1,
    'LINK': 15,
    'UNI': 5,
    'AAVE': 80,
    'DOGE': 0.1,
    'SHIB': 0.00001,
    'AVAX': 35,
    'ATOM': 10,
    'OP': 3,
    'ARB': 1.5,
    'SUI': 1,
    'APT': 8,
    'NEAR': 2,
    'FTM': 0.5
  };
  return basePrices[symbol] || 1;
}

function getBaseVolume(symbol: string): number {
  return symbol === 'BTC' ? 20000000000 : 
         symbol === 'ETH' ? 10000000000 : 
         1000000000 * (0.5 + Math.random());
}

function getBaseMarketCap(symbol: string): number {
  return symbol === 'BTC' ? 1000000000000 : 
         symbol === 'ETH' ? 500000000000 : 
         10000000000 * (0.8 + Math.random() * 0.4);
}

function getBaseSupply(symbol: string): number {
  const supplies: Record<string, number> = {
    'BTC': 19500000,
    'ETH': 120000000,
    'BNB': 200000000,
    'SOL': 500000000,
    'ADA': 35000000000,
    'DOGE': 140000000000,
    'SHIB': 589000000000000
  };
  return supplies[symbol] || 1000000000;
}