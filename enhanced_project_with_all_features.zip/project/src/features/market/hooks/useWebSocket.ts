import { useEffect, useCallback } from 'react';
import { WebSocketService } from '../services/WebSocketService';
import { PRICE_WEBSOCKET_URL } from '../api/apiConfig';

export function useWebSocket() {
  const wsService = WebSocketService.getInstance();

  const subscribe = useCallback((callback: (data: any) => void) => {
    return wsService.subscribe(callback);
  }, []);

  useEffect(() => {
    wsService.connect(PRICE_WEBSOCKET_URL);
    return () => wsService.disconnect();
  }, []);

  return { subscribe };
}