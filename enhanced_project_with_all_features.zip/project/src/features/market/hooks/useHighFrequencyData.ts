```typescript
import { useState, useEffect, useRef } from 'react';
import { HighFrequencyDataService, TickData } from '../services/HighFrequencyDataService';

const MAX_DATA_POINTS = 1000;

export function useHighFrequencyData(symbol: string) {
  const [tickData, setTickData] = useState<TickData[]>([]);
  const dataRef = useRef<TickData[]>([]);

  useEffect(() => {
    const service = HighFrequencyDataService.getInstance();
    
    const unsubscribe = service.subscribe(symbol, (tick) => {
      dataRef.current = [
        ...dataRef.current.slice(-MAX_DATA_POINTS + 1),
        tick
      ];
      setTickData([...dataRef.current]);
    });

    return () => unsubscribe();
  }, [symbol]);

  return {
    tickData,
    latestTick: tickData[tickData.length - 1]
  };
}
```