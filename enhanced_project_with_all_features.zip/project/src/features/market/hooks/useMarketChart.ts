import { useState, useEffect } from 'react';
import { MarketChartData } from '../types';
import { fetchMarketChart } from '../api/marketChartApi';

export function useMarketChart(coinId: string, days: number = 7) {
  const [chartData, setChartData] = useState<MarketChartData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadChartData = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const data = await fetchMarketChart(coinId, days);
        setChartData(data);
      } catch (err) {
        setError('Failed to load chart data');
        console.error('Chart data error:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadChartData();
    const interval = setInterval(loadChartData, 60000); // Update every minute
    return () => clearInterval(interval);
  }, [coinId, days]);

  return { chartData, isLoading, error };
}