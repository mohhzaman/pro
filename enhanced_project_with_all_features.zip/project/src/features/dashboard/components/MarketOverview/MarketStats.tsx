import React from 'react';
import { TrendingUp, Activity, DollarSign } from 'lucide-react';
import { useMarketData } from '../../../market/hooks/useMarketData';

export const MarketStats: React.FC = () => {
  const { marketData } = useMarketData();

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-lg font-semibold text-white mb-4">Market Overview</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-5 h-5 text-blue-400" />
            <span className="text-sm text-gray-400">Price</span>
          </div>
          <div className="text-xl font-semibold text-white">
            ${marketData.price.toFixed(2)}
          </div>
        </div>

        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-5 h-5 text-green-400" />
            <span className="text-sm text-gray-400">Volume</span>
          </div>
          <div className="text-xl font-semibold text-white">
            ${(marketData.volume / 1000000).toFixed(2)}M
          </div>
        </div>

        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-yellow-400" />
            <span className="text-sm text-gray-400">24h Change</span>
          </div>
          <div className="text-xl font-semibold text-green-400">
            +2.45%
          </div>
        </div>
      </div>
    </div>
  );
};